// Screens A — Home, Upload, Analysis, Workers list
// Mobile content area inside the iOS frame (~390px wide × ~860px tall, minus status/home).

const RP = (n) => 'Rp' + n.toLocaleString('id-ID');

// ─────────────────── 1. HOME / LANDING ───────────────────
function HomeScreen({ go }) {
  const [chip, setChip] = React.useState('AC Bocor');
  const quickServices = ['AC Bocor', 'Pipa Mampet', 'Listrik Mati', 'Bersih Rumah', 'Tukang Kebun'];
  const trustItems = [
    { Icn: Icon.Coin,  t: 'Estimasi harga\ntransparan' },
    { Icn: Icon.Shield, t: 'Tukang\nterverifikasi' },
    { Icn: Icon.Pin,   t: 'Rekomendasi\ndekat lokasi' },
  ];

  return (
    <FrameContent>
      {/* Hero block — green */}
      <div style={{
        position: 'relative',
        background: 'linear-gradient(180deg, #0E8E6C 0%, #0B7257 100%)',
        color: '#fff',
        padding: '56px 18px 28px',
        borderBottomLeftRadius: 36, borderBottomRightRadius: 36,
        overflow: 'hidden',
      }}>
        {/* deco circles */}
        <div style={{
          position: 'absolute', top: -80, right: -60,
          width: 240, height: 240, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(255,255,255,.10), transparent 60%)',
        }} />
        <div style={{
          position: 'absolute', bottom: -40, left: -40,
          width: 180, height: 180, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(245,158,60,.18), transparent 60%)',
        }} />

        {/* top row: brand + bell */}
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom: 18, position:'relative', zIndex: 2 }}>
          <div style={{ display:'flex', alignItems:'center', gap: 10 }}>
            <Logo size={34} />
            <div>
              <div style={{ fontSize: 18, fontWeight: 800, letterSpacing: -.4, lineHeight: 1 }}>Beresin</div>
              <div style={{ fontSize: 10.5, fontWeight: 600, color: 'rgba(255,255,255,.7)', display:'flex', alignItems:'center', gap: 4, marginTop: 2 }}>
                <Icon.Pin size={11} color="rgba(255,255,255,.7)" /> Tebet, Jakarta Selatan
              </div>
            </div>
          </div>
          <button style={{
            width: 38, height: 38, borderRadius: 19,
            background: 'rgba(255,255,255,.16)', border: 'none',
            display:'grid', placeItems:'center', cursor:'pointer',
            position:'relative',
          }}>
            <Icon.Bell size={18} color="#fff" />
            <span style={{
              position:'absolute', top: 9, right: 10, width: 8, height: 8,
              borderRadius: 4, background: 'var(--accent)', border: '1.5px solid #0E8E6C',
            }} />
          </button>
        </div>

        {/* hero copy */}
        <div style={{ position:'relative', zIndex: 2 }}>
          <div style={{
            display:'inline-flex', alignItems:'center', gap: 6,
            background:'rgba(255,255,255,.16)', padding: '5px 11px',
            borderRadius: 999, fontSize: 11, fontWeight: 700, marginBottom: 12,
            backdropFilter: 'blur(8px)',
          }}>
            <Icon.Sparkle size={12} color="#FFD89B" /> AI ASSISTANT • BARU
          </div>
          <div style={{
            fontSize: 26, fontWeight: 800, lineHeight: 1.18, letterSpacing: -.6,
            textWrap: 'pretty', maxWidth: 320,
          }}>
            Rusak di rumah?<br/>
            <span style={{ color: '#FFD89B' }}>Foto aja</span>, Beresin bantu<br/>cari tukangnya.
          </div>
          <div style={{
            marginTop: 10, fontSize: 13.5, lineHeight: 1.5,
            color: 'rgba(255,255,255,.85)', maxWidth: 320,
          }}>
            AI bantu analisis masalah, kasih estimasi harga, dan rekomendasi tukang terpercaya di sekitar kamu.
          </div>
        </div>

        {/* primary CTA card overlapping */}
        <div style={{ position:'relative', zIndex: 2, marginTop: 22 }}>
          <div onClick={() => go('upload')} style={{
            background: '#fff', borderRadius: 22,
            padding: 14,
            boxShadow: '0 12px 30px -10px rgba(0,0,0,.25)',
            display:'flex', alignItems:'center', gap: 12, cursor: 'pointer',
          }}>
            <div style={{
              width: 52, height: 52, borderRadius: 16,
              background: 'linear-gradient(135deg, var(--accent), #E37614)',
              display:'grid', placeItems:'center', flexShrink: 0,
              boxShadow: '0 6px 12px -4px rgba(245,158,60,.6)',
            }}>
              <Icon.Camera size={24} color="#fff" />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 15, fontWeight: 800, color: 'var(--ink)', letterSpacing: -.2 }}>Cek Masalah Sekarang</div>
              <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 2 }}>Foto kerusakan → AI analisis dalam 10 detik</div>
            </div>
            <div style={{
              width: 34, height: 34, borderRadius: 17,
              background: 'var(--ink)', color:'#fff',
              display:'grid', placeItems:'center', flexShrink: 0,
            }}>
              <Icon.ArrowRight size={16} color="#fff" />
            </div>
          </div>
        </div>
      </div>

      {/* Quick services */}
      <div style={{ padding: '20px 18px 0' }}>
        <div style={{ display:'flex', alignItems:'baseline', justifyContent:'space-between', marginBottom: 12 }}>
          <div style={{ fontSize: 15, fontWeight: 800, letterSpacing: -.2 }}>Masalah yang sering muncul</div>
          <button onClick={() => go('workers')} style={{
            background:'none', border:'none', color: 'var(--primary)',
            fontSize: 12, fontWeight: 700, cursor:'pointer', fontFamily: 'inherit',
          }}>Lihat semua</button>
        </div>
        <div style={{ display:'flex', gap: 8, overflowX: 'auto', paddingBottom: 4 }} className="noscroll">
          {quickServices.map(s => (
            <Chip key={s} active={chip===s} onClick={() => setChip(s)} variant="default">{s}</Chip>
          ))}
        </div>

        {/* Service grid */}
        <div style={{
          display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap: 10,
          marginTop: 14,
        }}>
          {[
            { kind:'AC',       label:'AC' },
            { kind:'Plumbing', label:'Pipa' },
            { kind:'Listrik',  label:'Listrik' },
            { kind:'Cleaning', label:'Bersih' },
            { kind:'Kebun',    label:'Kebun' },
            { kind:'Lainnya',  label:'Tukang' },
            { kind:'Lainnya',  label:'Cat' },
            { kind:'Lainnya',  label:'Lainnya' },
          ].map((s, i) => (
            <button key={i} onClick={() => go('upload')} style={{
              background:'#fff', border:'1px solid rgba(15,31,26,.05)',
              borderRadius: 16, padding: '12px 6px',
              display:'flex', flexDirection:'column', alignItems:'center', gap: 6,
              cursor:'pointer', fontFamily: 'inherit',
              boxShadow: '0 1px 0 rgba(0,0,0,.02)',
            }}>
              <ServiceIcon kind={s.kind} size={38} />
              <div style={{ fontSize: 11, fontWeight: 700, color:'var(--ink)' }}>{s.label}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Trust strip */}
      <div style={{ padding: '20px 18px 0' }}>
        <Card padding={14} style={{
          background: 'linear-gradient(135deg, #FFF8EE 0%, #FFFCF6 100%)',
          border: '1px solid #FFE9C2',
        }}>
          <div style={{ display:'flex', justifyContent:'space-between', gap: 6 }}>
            {trustItems.map(({ Icn, t }, i) => (
              <div key={i} style={{ flex: 1, display:'flex', flexDirection:'column', alignItems:'center', textAlign:'center', gap: 6 }}>
                <div style={{
                  width: 36, height: 36, borderRadius: 12,
                  background: 'var(--accent-50)', color: 'var(--accent-dark)',
                  display:'grid', placeItems:'center',
                }}>
                  <Icn size={18} color="var(--accent-dark)" />
                </div>
                <div style={{ fontSize: 11, fontWeight: 700, color:'var(--ink-2)', whiteSpace:'pre-line', lineHeight: 1.25 }}>{t}</div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Nearby workers preview */}
      <div style={{ padding: '20px 18px 0' }}>
        <div style={{ display:'flex', alignItems:'baseline', justifyContent:'space-between', marginBottom: 12 }}>
          <div>
            <div style={{ fontSize: 15, fontWeight: 800, letterSpacing: -.2 }}>Tukang dekat kamu</div>
            <div style={{ fontSize: 11.5, color:'var(--muted)', marginTop: 2 }}>3 tukang aktif dalam radius 2 km</div>
          </div>
          <button onClick={() => go('workers')} style={{
            background:'none', border:'none', color: 'var(--primary)',
            fontSize: 12, fontWeight: 700, cursor:'pointer', fontFamily: 'inherit',
          }}>Lihat semua</button>
        </div>

        <div style={{ display:'flex', gap: 12, overflowX:'auto', paddingBottom: 6, margin: '0 -18px', padding: '0 18px 6px' }} className="noscroll">
          {WORKERS.slice(0,3).map(w => (
            <div key={w.id} onClick={() => go('worker', { workerId: w.id })} style={{
              minWidth: 230, background:'#fff', borderRadius: 18, padding: 12,
              border:'1px solid rgba(15,31,26,.05)',
              boxShadow: '0 8px 24px -16px rgba(15,31,26,.12)', cursor:'pointer',
              flexShrink: 0,
            }}>
              <div style={{ display:'flex', alignItems:'center', gap: 10 }}>
                <Avatar name={w.name} size={42} />
                <div style={{ minWidth: 0, flex: 1 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 800, letterSpacing: -.2, display:'flex', alignItems:'center', gap: 4 }}>
                    {w.name}
                    <Icon.Verified size={12} />
                  </div>
                  <div style={{ fontSize: 11, color:'var(--muted)' }}>{w.service}</div>
                </div>
              </div>
              <div style={{ display:'flex', gap: 8, marginTop: 10, fontSize: 11, color:'var(--ink-2)', fontWeight: 600 }}>
                <span style={{ display:'inline-flex', alignItems:'center', gap: 3 }}>
                  <Icon.Star size={11} /> {w.rating}
                </span>
                <span style={{ color:'var(--line)' }}>•</span>
                <span style={{ display:'inline-flex', alignItems:'center', gap: 3 }}>
                  <Icon.Pin size={11} color="var(--muted)" /> {w.distance} km
                </span>
                <span style={{ color:'var(--line)' }}>•</span>
                <span style={{ display:'inline-flex', alignItems:'center', gap: 3 }}>
                  <Icon.Clock size={11} color="var(--muted)" /> {w.eta}
                </span>
              </div>
              <div style={{
                marginTop: 10, padding: '6px 10px', borderRadius: 10,
                background: 'var(--primary-50)', color: 'var(--primary-dark)',
                fontSize: 11.5, fontWeight: 700,
                display:'flex', alignItems:'center', justifyContent:'space-between',
              }}>
                <span>{RP(w.priceMin)} – {RP(w.priceMax)}</span>
                <Icon.ArrowRight size={14} color="var(--primary-dark)" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Promo banner */}
      <div style={{ padding: '20px 18px 0' }}>
        <Card padding={0} style={{
          background: 'linear-gradient(135deg, #1A2D26 0%, #0F1F1A 100%)',
          color: '#fff', border: 'none', overflow:'hidden', position:'relative',
        }}>
          <div style={{
            position:'absolute', right: -30, top: -20, width: 160, height: 160,
            borderRadius: '50%',
            background: 'radial-gradient(circle, rgba(245,158,60,.35), transparent 60%)',
          }} />
          <div style={{ padding: 16, position:'relative' }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: '#FFD89B', letterSpacing: .4 }}>PROMO WARGA TEBET</div>
            <div style={{ fontSize: 16, fontWeight: 800, marginTop: 4, letterSpacing: -.3, maxWidth: 240 }}>
              Cuci AC pertama gratis pengecekan
            </div>
            <div style={{ fontSize: 11.5, color: 'rgba(255,255,255,.65)', marginTop: 4 }}>
              Berlaku untuk 50 pelanggan baru bulan ini
            </div>
            <button onClick={() => go('upload')} style={{
              marginTop: 12, padding: '8px 14px', borderRadius: 10,
              background: 'var(--accent)', color: '#fff', border:'none',
              fontSize: 12.5, fontWeight: 800, cursor:'pointer', fontFamily:'inherit',
            }}>Klaim Sekarang</button>
          </div>
        </Card>
      </div>

      <div style={{ height: 12 }} />
    </FrameContent>
  );
}

// ─────────────────── Beresin logo (small "B" mark) ───────────────────
function Logo({ size = 40, mono = false }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: size*0.28,
      background: mono ? '#fff' : 'linear-gradient(135deg, #FFD89B 0%, #F59E3C 100%)',
      display:'grid', placeItems:'center',
      boxShadow: 'inset 0 -2px 6px rgba(0,0,0,.15), inset 0 1px 0 rgba(255,255,255,.4)',
      flexShrink: 0,
    }}>
      <svg width={size*0.55} height={size*0.55} viewBox="0 0 24 24">
        <path d="M5 4h7.5a4.5 4.5 0 0 1 2.4 8.3 5 5 0 0 1-2.7 9.2H5V4Zm3 3v6h4.5a3 3 0 0 0 0-6H8Zm0 9v5h5.2a2.5 2.5 0 0 0 0-5H8Z" fill={mono ? '#0E8E6C' : '#0F1F1A'}/>
      </svg>
    </div>
  );
}

// ─────────────────── 2. UPLOAD SCREEN ───────────────────
function UploadScreen({ go, state, setState }) {
  const cats = ['AC', 'Plumbing', 'Listrik', 'Cleaning', 'Kebun', 'Lainnya'];
  const urgencies = [
    { v: 'Normal',  hint: 'Bisa nunggu' },
    { v: 'Segera',  hint: 'Hari ini' },
    { v: 'Darurat', hint: 'Sekarang juga' },
  ];
  const desc = state.desc || '';
  const cat = state.cat || 'AC';
  const urgency = state.urgency || 'Segera';
  const hasPhoto = !!state.photo;

  const onUpload = () => setState({ ...state, photo: 'mock' });

  return (
    <FrameContent>
      <ScreenHeader
        subtitle="Langkah 1 dari 3"
        title="Apa yang bermasalah?"
        onBack={() => go('home')}
      />
      <div style={{ padding: '0 18px' }}>
        <div style={{ fontSize: 13.5, color:'var(--muted)', marginBottom: 14 }}>
          Upload foto kerusakan atau jelaskan masalahnya. AI bakal kasih estimasi harga dan rekomendasi tukang.
        </div>

        {/* Big upload area */}
        <div onClick={onUpload} style={{
          background: hasPhoto ? '#0F1F1A' : '#fff',
          border: hasPhoto ? 'none' : '1.5px dashed #B7C4BD',
          borderRadius: 22,
          padding: hasPhoto ? 0 : '32px 16px',
          minHeight: 200,
          display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
          gap: 10, cursor:'pointer',
          position:'relative', overflow:'hidden',
        }}>
          {hasPhoto ? (
            <div style={{ width: '100%', aspectRatio: '4/3', position:'relative' }}>
              {/* Mock photo of an AC unit */}
              <MockACPhoto />
              <button onClick={(e) => { e.stopPropagation(); setState({ ...state, photo: null }); }} style={{
                position:'absolute', top: 10, right: 10,
                background: 'rgba(0,0,0,.5)', color:'#fff', border:'none',
                width: 32, height: 32, borderRadius: 16, cursor:'pointer',
                display:'grid', placeItems:'center', fontSize: 16, fontWeight: 700,
                backdropFilter: 'blur(8px)',
              }}>×</button>
              <div style={{
                position:'absolute', left: 12, bottom: 12,
                padding: '6px 10px', borderRadius: 10,
                background: 'rgba(0,0,0,.55)', color:'#fff',
                fontSize: 11, fontWeight: 700, backdropFilter: 'blur(8px)',
                display:'flex', alignItems:'center', gap: 4,
              }}>
                <Icon.Check size={12} color="#7DE0AD" />
                Foto siap dianalisis
              </div>
            </div>
          ) : (
            <>
              <div style={{
                width: 64, height: 64, borderRadius: 32,
                background: 'linear-gradient(135deg, var(--primary-50), #fff)',
                color:'var(--primary)',
                display:'grid', placeItems:'center',
                boxShadow: 'inset 0 -2px 6px rgba(14,142,108,.08)',
              }}>
                <Icon.Camera size={28} color="var(--primary)" />
              </div>
              <div style={{ fontSize: 15, fontWeight: 800, color:'var(--ink)' }}>Ambil Foto / Upload</div>
              <div style={{ fontSize: 11.5, color:'var(--muted)', textAlign:'center', maxWidth: 240 }}>
                Foto membantu AI memberi estimasi yang lebih akurat
              </div>
              <div style={{ display:'flex', gap: 8, marginTop: 4 }}>
                <button onClick={(e)=>{e.stopPropagation(); onUpload();}} style={{
                  display:'inline-flex', alignItems:'center', gap: 6,
                  padding: '8px 14px', borderRadius: 10,
                  background: 'var(--ink)', color:'#fff', border:'none',
                  fontSize: 12, fontWeight: 700, cursor:'pointer', fontFamily:'inherit',
                }}>
                  <Icon.Camera size={14} color="#fff"/> Buka Kamera
                </button>
                <button onClick={(e)=>{e.stopPropagation(); onUpload();}} style={{
                  display:'inline-flex', alignItems:'center', gap: 6,
                  padding: '8px 14px', borderRadius: 10,
                  background: '#fff', color:'var(--ink-2)', border:'1px solid var(--line)',
                  fontSize: 12, fontWeight: 700, cursor:'pointer', fontFamily:'inherit',
                }}>
                  <Icon.Image size={14} color="var(--ink-2)"/> Galeri
                </button>
              </div>
            </>
          )}
        </div>

        {/* Description */}
        <div style={{ marginTop: 16 }}>
          <div style={{ fontSize: 12.5, fontWeight: 700, color:'var(--ink-2)', marginBottom: 8 }}>
            Ceritakan singkat <span style={{ color: 'var(--muted)', fontWeight: 500 }}>(opsional)</span>
          </div>
          <textarea
            value={desc}
            onChange={e => setState({ ...state, desc: e.target.value })}
            placeholder="Contoh: AC saya bocor dari dalam, sudah 2 hari."
            style={{
              width:'100%', minHeight: 84, padding: 14,
              background: '#fff', border:'1px solid var(--line)',
              borderRadius: 16,
              fontSize: 14, fontFamily: 'inherit', resize: 'none',
              color:'var(--ink)', outline:'none',
              boxShadow: '0 1px 0 rgba(0,0,0,.02)',
            }}
          />
        </div>

        {/* Category */}
        <div style={{ marginTop: 16 }}>
          <div style={{ fontSize: 12.5, fontWeight: 700, color:'var(--ink-2)', marginBottom: 8 }}>Kategori</div>
          <div style={{ display:'flex', flexWrap:'wrap', gap: 8 }}>
            {cats.map(c => (
              <Chip key={c} active={cat===c} onClick={() => setState({ ...state, cat: c })} variant="primary">
                {c}
              </Chip>
            ))}
          </div>
        </div>

        {/* Urgency */}
        <div style={{ marginTop: 16 }}>
          <div style={{ fontSize: 12.5, fontWeight: 700, color:'var(--ink-2)', marginBottom: 8 }}>Tingkat keparahan</div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap: 8 }}>
            {urgencies.map(({ v, hint }) => {
              const active = urgency === v;
              const isDanger = v === 'Darurat';
              return (
                <button key={v} onClick={() => setState({ ...state, urgency: v })} style={{
                  background: active ? (isDanger ? '#FBE9E2' : 'var(--primary-50)') : '#fff',
                  border: '1.5px solid ' + (active ? (isDanger ? '#D6553B' : 'var(--primary)') : 'var(--line)'),
                  borderRadius: 14, padding: '10px 8px',
                  cursor:'pointer', fontFamily:'inherit',
                  textAlign:'center',
                }}>
                  <div style={{
                    fontSize: 13.5, fontWeight: 800,
                    color: active ? (isDanger ? '#A93B22' : 'var(--primary-dark)') : 'var(--ink)',
                    display:'flex', alignItems:'center', justifyContent:'center', gap: 4,
                  }}>
                    {isDanger && active && <Icon.Bolt size={13} color="#A93B22" />}
                    {v}
                  </div>
                  <div style={{ fontSize: 10.5, color:'var(--muted)', marginTop: 2 }}>{hint}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* CTA */}
        <div style={{ marginTop: 22, marginBottom: 8 }}>
          <Button variant="primary" size="lg" full
            onClick={() => go('analyzing')}
            icon={<Icon.Sparkle size={18} color="#fff" />}
            iconRight={<Icon.ArrowRight size={18} color="#fff" />}
          >
            Analisis dengan AI
          </Button>
          <div style={{ fontSize: 11, color:'var(--muted)', textAlign:'center', marginTop: 8 }}>
            Gratis · biasanya selesai dalam 8 detik
          </div>
        </div>
      </div>
    </FrameContent>
  );
}

// Mock photo placeholder (looks like an AC unit)
function MockACPhoto() {
  return (
    <div style={{
      position:'absolute', inset: 0,
      background: 'linear-gradient(180deg, #C9D7CF 0%, #889B92 100%)',
    }}>
      {/* wall */}
      <div style={{
        position:'absolute', inset: 0,
        background: 'repeating-linear-gradient(0deg, rgba(255,255,255,.04) 0 2px, transparent 2px 24px)',
      }} />
      {/* AC unit */}
      <div style={{
        position:'absolute', left: '15%', right: '15%', top: '18%',
        height: '38%',
        background: 'linear-gradient(180deg, #fafafa 0%, #d6d6d6 100%)',
        borderRadius: 14,
        boxShadow: '0 20px 30px -15px rgba(0,0,0,.4), inset 0 -3px 0 rgba(0,0,0,.06)',
      }}>
        <div style={{
          position:'absolute', left: 8, right: 8, bottom: 8, top: '38%',
          background: 'repeating-linear-gradient(0deg, #c8ccca 0 2px, #e6e9e7 2px 5px)',
          borderRadius: 6,
        }} />
        <div style={{
          position:'absolute', left: 16, top: 12, fontSize: 7, fontWeight: 800, color:'#999',
        }}>SEJUKAIR</div>
      </div>
      {/* drip / leak */}
      <div style={{
        position:'absolute', left: '32%', top: '56%', width: 4, height: 60,
        background: 'linear-gradient(180deg, rgba(80,140,180,.85), rgba(80,140,180,.2))',
        borderRadius: 4, filter: 'blur(.5px)',
      }} />
      <div style={{
        position:'absolute', left: '30%', top: '78%', width: 32, height: 18,
        background: 'radial-gradient(ellipse at center, rgba(80,140,180,.55), transparent 70%)',
        filter: 'blur(2px)',
      }} />
      {/* AI scan overlay */}
      <div style={{
        position:'absolute', left: '28%', top: '52%', width: 70, height: 90,
        border: '2px solid #FFD89B',
        borderRadius: 8,
        boxShadow: '0 0 0 9999px rgba(0,0,0,.0), inset 0 0 0 2px rgba(255,216,155,.3)',
      }}>
        <div style={{
          position:'absolute', left: -2, top: -2, width: 14, height: 14,
          borderTop:'3px solid #FFD89B', borderLeft:'3px solid #FFD89B', borderRadius: '4px 0 0 0',
        }} />
        <div style={{
          position:'absolute', right: -2, top: -2, width: 14, height: 14,
          borderTop:'3px solid #FFD89B', borderRight:'3px solid #FFD89B', borderRadius: '0 4px 0 0',
        }} />
        <div style={{
          position:'absolute', left: -2, bottom: -2, width: 14, height: 14,
          borderBottom:'3px solid #FFD89B', borderLeft:'3px solid #FFD89B', borderRadius: '0 0 0 4px',
        }} />
        <div style={{
          position:'absolute', right: -2, bottom: -2, width: 14, height: 14,
          borderBottom:'3px solid #FFD89B', borderRight:'3px solid #FFD89B', borderRadius: '0 0 4px 0',
        }} />
      </div>
    </div>
  );
}

// ─────────────────── 2.5 ANALYZING (loader) ───────────────────
function AnalyzingScreen({ go }) {
  const [step, setStep] = React.useState(0);
  const steps = [
    'Membaca foto kerusakan…',
    'Mendeteksi pola masalah…',
    'Mencari estimasi harga wajar…',
    'Memilih tukang terdekat…',
  ];
  React.useEffect(() => {
    const t1 = setTimeout(() => setStep(1), 700);
    const t2 = setTimeout(() => setStep(2), 1500);
    const t3 = setTimeout(() => setStep(3), 2300);
    const t4 = setTimeout(() => go('result'), 3200);
    return () => [t1,t2,t3,t4].forEach(clearTimeout);
  }, []);

  return (
    <FrameContent withNav={false} bg="linear-gradient(180deg, #0E8E6C 0%, #0A6E54 100%)">
      <div style={{
        position:'absolute', inset: 0, padding: '0 24px',
        display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
        color:'#fff', textAlign:'center',
      }}>
        {/* Photo with scan */}
        <div className="br-pop" style={{
          width: 220, aspectRatio: '4/3', borderRadius: 20, overflow:'hidden',
          position:'relative',
          boxShadow: '0 30px 50px -20px rgba(0,0,0,.5)',
        }}>
          <MockACPhoto />
          {/* scan line */}
          <div style={{
            position:'absolute', left: 0, right: 0, height: 30,
            background: 'linear-gradient(180deg, rgba(255,216,155,0) 0%, rgba(255,216,155,.7) 50%, rgba(255,216,155,0) 100%)',
            animation: 'scanline 1.6s ease-in-out infinite',
          }} />
        </div>

        <div style={{ marginTop: 28, fontSize: 11, fontWeight: 700, color:'#FFD89B', letterSpacing: .8 }}>BERESIN AI</div>
        <div style={{ marginTop: 4, fontSize: 22, fontWeight: 800, letterSpacing: -.4 }}>Lagi mikir…</div>
        <div style={{ marginTop: 6, fontSize: 13, color:'rgba(255,255,255,.7)', maxWidth: 260 }}>
          AI sedang menganalisis foto dan mencari pola masalah dari ribuan kasus sejenis.
        </div>

        {/* steps */}
        <div style={{ marginTop: 24, width: '100%', maxWidth: 280, textAlign:'left' }}>
          {steps.map((s, i) => (
            <div key={i} style={{
              display:'flex', alignItems:'center', gap: 10,
              padding: '8px 0',
              opacity: i <= step ? 1 : .4,
              transition: 'opacity .3s ease',
            }}>
              <div style={{
                width: 22, height: 22, borderRadius: 11,
                background: i < step ? '#FFD89B' : (i === step ? 'rgba(255,255,255,.2)' : 'rgba(255,255,255,.08)'),
                display:'grid', placeItems:'center', flexShrink: 0,
                color: i < step ? '#0F1F1A' : '#fff',
              }}>
                {i < step
                  ? <Icon.Check size={12} color="#0F1F1A" />
                  : (i === step
                    ? <div style={{ width:10, height:10, border:'2px solid #FFD89B', borderTopColor:'transparent', borderRadius:'50%', animation:'spin .8s linear infinite' }}/>
                    : <span style={{ fontSize: 10, fontWeight: 700, opacity: .6 }}>{i+1}</span>)
                }
              </div>
              <div style={{ fontSize: 13, fontWeight: 600, color:'#fff' }}>{s}</div>
            </div>
          ))}
        </div>
      </div>
    </FrameContent>
  );
}

Object.assign(window, { HomeScreen, UploadScreen, AnalyzingScreen, Logo, MockACPhoto, RP });
