// Worker data
const WORKERS = [
  {
    id: 'rudi',
    name: 'Pak Rudi',
    service: 'Teknisi AC',
    serviceKind: 'AC',
    rating: 4.9,
    reviews: 186,
    distance: 1.2,
    eta: '20 menit',
    priceMin: 80000, priceMax: 130000,
    review: 'Datang cepat, AC langsung dingin lagi.',
    badges: ['Terverifikasi', 'Harga Transparan', '12× direkomendasikan warga'],
    jobsDone: 328,
    services: [
      { name: 'Cuci AC',          min: 80000,  max: 120000 },
      { name: 'Cek AC bocor',     min: 100000, max: 150000 },
      { name: 'Isi freon',        min: 150000, max: null },
      { name: 'Bongkar pasang',   min: 250000, max: 350000 },
    ],
    bio: 'Sudah 9 tahun nukang AC di Tebet. Spesialis split & cassette. Garansi 7 hari setelah service.',
    available: 'Bisa hari ini · 09.00 – 21.00',
  },
  {
    id: 'sari',
    name: 'Bu Sari Clean',
    service: 'Cleaning Service',
    serviceKind: 'Cleaning',
    rating: 4.8,
    reviews: 142,
    distance: 2.1,
    eta: 'Bisa hari ini',
    priceMin: 100000, priceMax: 250000,
    review: 'Rapi dan teliti, cocok untuk bersih-bersih kos.',
    badges: ['Terverifikasi', 'Tim Wanita', '8× direkomendasikan'],
    jobsDone: 211,
    services: [
      { name: 'Bersih kamar kos', min: 100000, max: 150000 },
      { name: 'Bersih rumah 2BR', min: 200000, max: 250000 },
      { name: 'Cuci sofa',        min: 150000, max: 250000 },
    ],
    bio: 'Tim 3 orang berpengalaman. Bawa peralatan & sabun sendiri. Bisa booked H-1.',
    available: 'Bisa besok pagi · 08.00 – 17.00',
  },
  {
    id: 'dedi',
    name: 'Pak Dedi',
    service: 'Tukang Ledeng',
    serviceKind: 'Plumbing',
    rating: 4.7,
    reviews: 98,
    distance: 1.8,
    eta: '35 menit',
    priceMin: 75000, priceMax: 200000,
    review: 'Harga sesuai estimasi, kerja cepat.',
    badges: ['Terverifikasi', 'Harga Transparan'],
    jobsDone: 174,
    services: [
      { name: 'Pipa mampet',      min: 75000,  max: 150000 },
      { name: 'Bocor wastafel',   min: 100000, max: 200000 },
      { name: 'Ganti kran',       min: 50000,  max: 120000 },
    ],
    bio: 'Tukang ledeng senior, area Tebet & Manggarai. Jaminan tidak balik bocor 14 hari.',
    available: 'Bisa hari ini · 07.00 – 22.00',
  },
  {
    id: 'budi',
    name: 'Pak Budi',
    service: 'Teknisi AC',
    serviceKind: 'AC',
    rating: 4.6,
    reviews: 64,
    distance: 2.4,
    eta: '40 menit',
    priceMin: 70000, priceMax: 110000,
    review: 'Ramah, jelasin masalahnya detail.',
    badges: ['Terverifikasi'],
    jobsDone: 92,
    services: [
      { name: 'Cuci AC', min: 70000, max: 110000 },
      { name: 'Cek AC',  min: 80000, max: 120000 },
    ],
    bio: 'Baru gabung 8 bulan, sudah 92 pekerjaan dengan rating 4.6.',
    available: 'Bisa hari ini · 10.00 – 18.00',
  },
];

// Helper for star rendering
function Stars({ value=4.5, size=12 }) {
  return (
    <span style={{ display:'inline-flex', alignItems:'center', gap: 1 }}>
      <Icon.Star size={size} />
      <span style={{ fontSize: size, fontWeight: 700, color:'var(--ink)', marginLeft: 2 }}>{value}</span>
    </span>
  );
}

// ─────────────────── 3. AI ANALYSIS RESULT ───────────────────
function ResultScreen({ go, state }) {
  return (
    <FrameContent>
      <ScreenHeader subtitle="Langkah 2 dari 3" title="Hasil Analisis" onBack={() => go('upload')} />
      <div style={{ padding: '0 18px' }}>

        {/* Top result card */}
        <Card padding={0} style={{
          background: 'linear-gradient(160deg, #0E8E6C 0%, #0A6E54 100%)',
          color:'#fff', border:'none', overflow:'hidden', position:'relative',
        }}>
          {/* sparkles */}
          <div style={{ position:'absolute', top: 12, right: 14, opacity:.35 }}>
            <Icon.Sparkle size={42} color="#FFD89B" />
          </div>
          <div style={{ padding: 16, position:'relative' }}>
            <div style={{ display:'flex', alignItems:'center', gap: 8, marginBottom: 10 }}>
              <span style={{
                display:'inline-flex', alignItems:'center', gap: 4,
                background:'rgba(255,255,255,.18)', padding:'4px 9px', borderRadius: 999,
                fontSize: 10.5, fontWeight: 800, letterSpacing: .3,
              }}>
                <Icon.Sparkle size={11} color="#FFD89B" /> AKURASI 87%
              </span>
              <span style={{
                display:'inline-flex', alignItems:'center', gap: 4,
                background:'rgba(255,255,255,.18)', padding:'4px 9px', borderRadius: 999,
                fontSize: 10.5, fontWeight: 800, letterSpacing: .3,
              }}>TEKNISI AC</span>
            </div>
            <div style={{ fontSize: 11, color:'#FFD89B', fontWeight: 700, letterSpacing: .4 }}>KEMUNGKINAN MASALAH</div>
            <div style={{ fontSize: 19, fontWeight: 800, lineHeight: 1.25, marginTop: 4, letterSpacing: -.3, textWrap:'pretty' }}>
              Saluran drainase AC tersumbat
            </div>
            <div style={{ fontSize: 12.5, color: 'rgba(255,255,255,.78)', marginTop: 8, lineHeight: 1.5 }}>
              Gejala ini biasanya terjadi karena saluran pembuangan air kotor tersumbat atau evaporator terlalu kotor.
            </div>

            {/* mini photo + meta */}
            <div style={{
              marginTop: 14,
              background: 'rgba(0,0,0,.18)', borderRadius: 14,
              padding: 10, display:'flex', alignItems:'center', gap: 10,
            }}>
              <div style={{ width: 56, height: 56, borderRadius: 10, overflow:'hidden', position:'relative', flexShrink: 0 }}>
                <MockACPhoto />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display:'flex', gap: 6, marginBottom: 4 }}>
                  <Tag color="accent" style={{ background:'rgba(245,158,60,.25)', color:'#FFD89B' }}>SEDANG</Tag>
                  <Tag color="danger" style={{ background:'rgba(214,85,59,.25)', color:'#FFB59E' }}>SEGERA</Tag>
                </div>
                <div style={{ fontSize: 11, color:'rgba(255,255,255,.7)' }}>
                  AC bocor dari dalam, sudah 2 hari. Foto menunjukkan tetesan air di unit indoor.
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Estimate cards */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap: 10, marginTop: 12 }}>
          <Card padding={14}>
            <div style={{ display:'flex', alignItems:'center', gap: 6, marginBottom: 4 }}>
              <Icon.Coin size={14} color="var(--accent-dark)" />
              <div style={{ fontSize: 10.5, fontWeight: 800, color:'var(--accent-dark)', letterSpacing: .3 }}>ESTIMASI BIAYA</div>
            </div>
            <div style={{ fontSize: 15, fontWeight: 800, letterSpacing: -.3, lineHeight: 1.2 }}>
              {RP(75000)}<br/>
              <span style={{ color:'var(--muted)', fontWeight: 600, fontSize: 13 }}>– {RP(150000)}</span>
            </div>
            <div style={{ fontSize: 10.5, color:'var(--muted)', marginTop: 4 }}>harga wajar di Tebet</div>
          </Card>
          <Card padding={14}>
            <div style={{ display:'flex', alignItems:'center', gap: 6, marginBottom: 4 }}>
              <Icon.Clock size={14} color="var(--primary-dark)" />
              <div style={{ fontSize: 10.5, fontWeight: 800, color:'var(--primary-dark)', letterSpacing: .3 }}>PERKIRAAN</div>
            </div>
            <div style={{ fontSize: 15, fontWeight: 800, letterSpacing: -.3, lineHeight: 1.2 }}>
              30 – 60<br/>
              <span style={{ color:'var(--muted)', fontWeight: 600, fontSize: 13 }}>menit pengerjaan</span>
            </div>
            <div style={{ fontSize: 10.5, color:'var(--muted)', marginTop: 4 }}>1 teknisi · cek + bersih</div>
          </Card>
        </div>

        {/* Recommendation */}
        <Card padding={14} style={{ marginTop: 12 }}>
          <div style={{ display:'flex', alignItems:'flex-start', gap: 10 }}>
            <div style={{
              width: 32, height: 32, borderRadius: 10,
              background: 'var(--primary-50)', color:'var(--primary-dark)',
              display:'grid', placeItems:'center', flexShrink: 0,
            }}>
              <Icon.Sparkle size={16} color="var(--primary-dark)" />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 800, color:'var(--ink)' }}>Rekomendasi Beresin</div>
              <div style={{ fontSize: 12.5, color:'var(--ink-2)', marginTop: 4, lineHeight: 1.5 }}>
                Disarankan panggil teknisi AC untuk pengecekan & pembersihan saluran drainase. Jangan tutup AC dengan handuk—berisiko jamur.
              </div>
            </div>
          </div>
        </Card>

        {/* CTA group */}
        <div style={{ marginTop: 16, display:'flex', flexDirection:'column', gap: 8 }}>
          <Button variant="primary" size="lg" full
            onClick={() => go('workers')}
            iconRight={<Icon.ArrowRight size={18} color="#fff" />}
          >
            Cari Teknisi Terdekat
          </Button>
          <Button variant="secondary" size="md" full
            onClick={() => {}}
            icon={<Icon.Sparkle size={16} color="var(--primary)" />}
          >
            Tanya AI Dulu
          </Button>
        </div>

        {/* Disclaimer */}
        <div style={{
          marginTop: 14, padding: '10px 12px', borderRadius: 12,
          background: '#FFF8EE', border: '1px solid #FFE9C2',
          fontSize: 11, color:'#8A5A14', lineHeight: 1.5,
          display:'flex', gap: 8, alignItems:'flex-start',
        }}>
          <Icon.Shield size={14} color="#B57008" />
          <span>Estimasi dapat berubah setelah teknisi melakukan pengecekan langsung di lokasi.</span>
        </div>
      </div>
    </FrameContent>
  );
}

// ─────────────────── 4. WORKERS LIST ───────────────────
function WorkersScreen({ go }) {
  const [filter, setFilter] = React.useState('Terdekat');
  const filters = ['Terdekat', 'Rating Tertinggi', 'Harga Terjangkau', 'Bisa Hari Ini'];
  const sorted = React.useMemo(() => {
    const w = [...WORKERS];
    if (filter === 'Terdekat') w.sort((a,b) => a.distance - b.distance);
    if (filter === 'Rating Tertinggi') w.sort((a,b) => b.rating - a.rating);
    if (filter === 'Harga Terjangkau') w.sort((a,b) => a.priceMin - b.priceMin);
    if (filter === 'Bisa Hari Ini') w.sort((a,b) => (a.eta.includes('menit')?-1:1));
    return w;
  }, [filter]);

  return (
    <FrameContent>
      <ScreenHeader
        subtitle="Langkah 3 dari 3"
        title="Teknisi Terdekat"
        onBack={() => go('result')}
        right={<button style={{
          width: 38, height: 38, borderRadius: 19, background:'#fff',
          border: '1px solid var(--line)', display:'grid', placeItems:'center', cursor:'pointer',
        }}>
          <Icon.Search size={18} color="var(--ink-2)" />
        </button>}
      />

      <div style={{ padding: '0 18px' }}>
        {/* Context strip */}
        <div style={{
          padding: '10px 12px', borderRadius: 14,
          background: 'var(--primary-50)', border:'1px solid #C5E2D6',
          display:'flex', alignItems:'center', gap: 10, marginBottom: 12,
        }}>
          <div style={{
            width: 28, height: 28, borderRadius: 8,
            background: 'var(--primary)', color:'#fff',
            display:'grid', placeItems:'center', flexShrink: 0,
          }}>
            <Icon.Sparkle size={14} color="#fff" />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color:'var(--primary-dark)' }}>Untuk: Saluran AC tersumbat</div>
            <div style={{ fontSize: 11, color:'var(--ink-2)' }}>4 teknisi cocok · radius 3 km · Tebet</div>
          </div>
        </div>

        {/* Filter chips */}
        <div style={{ display:'flex', gap: 8, overflowX:'auto', paddingBottom: 4, margin: '0 -18px', padding: '0 18px 6px' }} className="noscroll">
          {filters.map(f => (
            <Chip key={f} active={filter===f} onClick={() => setFilter(f)}>{f}</Chip>
          ))}
        </div>

        {/* Worker cards */}
        <div style={{ display:'flex', flexDirection:'column', gap: 12, marginTop: 8 }}>
          {sorted.map((w, idx) => (
            <WorkerCard key={w.id} w={w} go={go} featured={idx === 0} />
          ))}
        </div>
      </div>
    </FrameContent>
  );
}

function WorkerCard({ w, go, featured }) {
  return (
    <Card padding={0} style={{
      overflow:'hidden',
      border: featured ? '1.5px solid var(--primary)' : undefined,
      boxShadow: featured ? '0 8px 24px -10px rgba(14,142,108,.3)' : undefined,
    }}>
      {featured && (
        <div style={{
          padding: '6px 14px', background: 'var(--primary)', color: '#fff',
          fontSize: 10.5, fontWeight: 800, letterSpacing: .4,
          display:'flex', alignItems:'center', gap: 5,
        }}>
          <Icon.Sparkle size={11} color="#FFD89B" /> PALING DIREKOMENDASIKAN AI
        </div>
      )}
      <div style={{ padding: 14 }}>
        <div style={{ display:'flex', gap: 12 }}>
          <Avatar name={w.name} size={52} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display:'flex', alignItems:'center', gap: 5, marginBottom: 1 }}>
              <span style={{ fontSize: 14.5, fontWeight: 800, letterSpacing: -.2 }}>{w.name}</span>
              <Icon.Verified size={13} />
            </div>
            <div style={{ fontSize: 11.5, color: 'var(--muted)', marginBottom: 4 }}>{w.service} · {w.jobsDone || '—'} pekerjaan</div>
            <div style={{ display:'flex', alignItems:'center', gap: 8, fontSize: 11.5, color:'var(--ink-2)', fontWeight: 600 }}>
              <Stars value={w.rating} size={12} />
              <span style={{ color:'var(--line)' }}>•</span>
              <span style={{ display:'inline-flex', alignItems:'center', gap: 3 }}><Icon.Pin size={12} color="var(--muted)" /> {w.distance} km</span>
              <span style={{ color:'var(--line)' }}>•</span>
              <span style={{ display:'inline-flex', alignItems:'center', gap: 3 }}><Icon.Clock size={12} color="var(--muted)" /> {w.eta}</span>
            </div>
          </div>
        </div>

        {/* Badges */}
        <div style={{ display:'flex', flexWrap:'wrap', gap: 5, marginTop: 10 }}>
          {w.badges.map((b, i) => (
            <Tag key={i} color={i===0 ? 'success' : i===1 ? 'accent' : 'neutral'}
              icon={i===0 ? <Icon.Check size={10} color="#0F7A45" /> : null}
            >{b}</Tag>
          ))}
        </div>

        {/* Review snippet */}
        <div style={{
          marginTop: 10, padding: '8px 10px', borderRadius: 10,
          background: 'var(--bg)',
          fontSize: 11.5, color:'var(--ink-2)', lineHeight: 1.5,
          display:'flex', gap: 6,
        }}>
          <span style={{ color:'var(--muted)' }}>“</span>
          <span style={{ flex: 1, fontStyle: 'italic' }}>{w.review}</span>
        </div>

        {/* Footer: price + CTAs */}
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', gap: 10, marginTop: 12 }}>
          <div>
            <div style={{ fontSize: 10.5, fontWeight: 700, color:'var(--muted)', letterSpacing: .3 }}>HARGA</div>
            <div style={{ fontSize: 13, fontWeight: 800, color:'var(--ink)' }}>
              {RP(w.priceMin)} – {RP(w.priceMax)}
            </div>
          </div>
          <div style={{ display:'flex', gap: 6 }}>
            <Button variant="secondary" size="sm" onClick={() => go('worker', { workerId: w.id })}>
              Profil
            </Button>
            <Button variant="primary" size="sm" onClick={() => go('booking', { workerId: w.id })}
              icon={<Icon.Whatsapp size={14} />}
            >
              Hubungi
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}

// ─────────────────── 5. WORKER PROFILE ───────────────────
function WorkerProfileScreen({ go, state }) {
  const w = WORKERS.find(x => x.id === state.workerId) || WORKERS[0];
  return (
    <FrameContent>
      {/* hero */}
      <div style={{
        background: 'linear-gradient(180deg, #0E8E6C 0%, #0A6E54 100%)',
        color:'#fff',
        padding: '54px 18px 70px',
        borderBottomLeftRadius: 32, borderBottomRightRadius: 32,
        position:'relative', overflow:'hidden',
      }}>
        <div style={{
          position:'absolute', top: -60, right: -60, width: 200, height: 200, borderRadius:'50%',
          background:'radial-gradient(circle, rgba(255,255,255,.10), transparent 60%)',
        }} />
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', position:'relative', zIndex: 1 }}>
          <button onClick={() => go('workers')} style={{
            width: 38, height: 38, borderRadius: 19,
            background: 'rgba(255,255,255,.16)', border:'none', color:'#fff',
            display:'grid', placeItems:'center', cursor:'pointer',
          }}>
            <Icon.ChevronLeft size={20} color="#fff" />
          </button>
          <div style={{ display:'flex', gap: 8 }}>
            <button style={{
              width: 38, height: 38, borderRadius: 19,
              background: 'rgba(255,255,255,.16)', border:'none', color:'#fff',
              display:'grid', placeItems:'center', cursor:'pointer',
            }}>
              <Icon.Bookmark size={18} color="#fff" />
            </button>
          </div>
        </div>
      </div>

      <div style={{ padding: '0 18px', marginTop: -52 }}>
        {/* identity card */}
        <Card padding={16} style={{ position:'relative' }}>
          <div style={{ display:'flex', alignItems:'flex-start', gap: 14 }}>
            <div style={{
              padding: 3, background:'#fff', borderRadius: 36,
              boxShadow: '0 6px 16px -8px rgba(0,0,0,.2)',
              marginTop: -32,
            }}>
              <Avatar name={w.name} size={64} />
            </div>
            <div style={{ flex: 1, paddingTop: 2 }}>
              <div style={{ display:'flex', alignItems:'center', gap: 5 }}>
                <span style={{ fontSize: 18, fontWeight: 800, letterSpacing: -.3 }}>{w.name}</span>
                <Icon.Verified size={15} />
              </div>
              <div style={{ fontSize: 12, color:'var(--muted)', marginTop: 2 }}>{w.service}</div>
              <div style={{ display:'flex', gap: 8, marginTop: 8, fontSize: 12, fontWeight: 700, color:'var(--ink)' }}>
                <span style={{ display:'inline-flex', alignItems:'center', gap: 3 }}>
                  <Icon.Star size={13} /> {w.rating} <span style={{ color:'var(--muted)', fontWeight: 500 }}>({w.reviews})</span>
                </span>
                <span style={{ color:'var(--line)' }}>•</span>
                <span style={{ color:'var(--ink-2)' }}>{w.jobsDone} pekerjaan</span>
              </div>
            </div>
          </div>

          {/* Quick stats */}
          <div style={{
            display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap: 1,
            marginTop: 14, background: 'var(--line)',
            borderRadius: 14, overflow:'hidden',
          }}>
            {[
              { l: 'Jarak', v: `${w.distance} km`, Icn: Icon.Pin },
              { l: 'ETA',   v: w.eta,    Icn: Icon.Clock },
              { l: 'Mulai', v: RP(w.priceMin), Icn: Icon.Coin },
            ].map((s, i) => (
              <div key={i} style={{ background:'#fff', padding: '10px 8px', textAlign:'center' }}>
                <s.Icn size={14} color="var(--primary)" />
                <div style={{ fontSize: 13, fontWeight: 800, marginTop: 3 }}>{s.v}</div>
                <div style={{ fontSize: 10.5, color:'var(--muted)' }}>{s.l}</div>
              </div>
            ))}
          </div>

          <div style={{ fontSize: 12.5, color:'var(--ink-2)', marginTop: 12, lineHeight: 1.55 }}>
            {w.bio}
          </div>
        </Card>

        {/* Verification */}
        <SectionTitle>Verifikasi & Kepercayaan</SectionTitle>
        <Card padding={4}>
          {[
            { Icn: Icon.Shield, t: 'Identitas terverifikasi', d: 'KTP & nomor HP dicek' },
            { Icn: Icon.Phone,  t: 'Nomor aktif',             d: 'Diverifikasi 12 Mei 2026' },
            { Icn: Icon.Coin,   t: 'Harga transparan',        d: 'Mengikuti standar Beresin' },
            { Icn: Icon.Pin,    t: 'Direkomendasikan warga',  d: '12× direkomendasikan tetangga sekitar' },
          ].map((v, i, arr) => (
            <div key={i} style={{
              display:'flex', alignItems:'center', gap: 12, padding: '12px 12px',
              borderBottom: i < arr.length-1 ? '1px solid var(--line-2)' : 'none',
            }}>
              <div style={{
                width: 34, height: 34, borderRadius: 10,
                background:'var(--primary-50)', color:'var(--primary-dark)',
                display:'grid', placeItems:'center',
              }}>
                <v.Icn size={16} color="var(--primary-dark)" />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 700 }}>{v.t}</div>
                <div style={{ fontSize: 11, color:'var(--muted)' }}>{v.d}</div>
              </div>
              <div style={{
                width: 22, height: 22, borderRadius: 11, background:'var(--primary)',
                display:'grid', placeItems:'center', flexShrink: 0,
              }}>
                <Icon.Check size={12} color="#fff" />
              </div>
            </div>
          ))}
        </Card>

        {/* Services & price list */}
        <SectionTitle right="Lengkap di chat">Layanan & Harga</SectionTitle>
        <Card padding={4}>
          {w.services.map((s, i, arr) => (
            <div key={i} style={{
              display:'flex', alignItems:'center', gap: 12, padding: '12px 14px',
              borderBottom: i < arr.length-1 ? '1px solid var(--line-2)' : 'none',
            }}>
              <ServiceIcon kind={w.serviceKind} size={36} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 700 }}>{s.name}</div>
                <div style={{ fontSize: 11, color:'var(--muted)' }}>Termasuk garansi 7 hari</div>
              </div>
              <div style={{ fontSize: 12.5, fontWeight: 800, textAlign:'right', flexShrink: 0 }}>
                {s.max ? <>{RP(s.min)}<br/><span style={{ color:'var(--muted)', fontWeight: 600, fontSize: 11 }}>– {RP(s.max)}</span></>
                       : <>Mulai<br/>{RP(s.min)}</>}
              </div>
            </div>
          ))}
        </Card>

        {/* Reviews */}
        <SectionTitle right={`Lihat ${w.reviews}`}>Ulasan Terbaru</SectionTitle>
        <div style={{ display:'flex', flexDirection:'column', gap: 10 }}>
          {[
            { name:'Mbak Tia',   t:'Datang cepat, AC langsung dingin lagi. Harganya juga sesuai estimasi di app.', stars:5, when:'2 hari lalu' },
            { name:'Pak Joko',  t:'Cuci AC bersih banget. Ramah, jelasin masalahnya satu-satu.', stars:5, when:'1 minggu lalu' },
            { name:'Ibu Mira', t:'Kerja rapih. Cuma agak telat 15 menit dari janji.', stars:4, when:'2 minggu lalu' },
          ].map((r, i) => (
            <Card key={i} padding={12}>
              <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                <div style={{ display:'flex', gap: 8, alignItems:'center' }}>
                  <Avatar name={r.name} size={28} />
                  <div>
                    <div style={{ fontSize: 12.5, fontWeight: 700 }}>{r.name}</div>
                    <div style={{ fontSize: 10.5, color:'var(--muted)' }}>{r.when}</div>
                  </div>
                </div>
                <div style={{ display:'flex', gap: 1 }}>
                  {[1,2,3,4,5].map(n => <Icon.Star key={n} size={11} color={n<=r.stars?'#F59E3C':'#E5EAE5'}/>)}
                </div>
              </div>
              <div style={{ fontSize: 12.5, color:'var(--ink-2)', marginTop: 8, lineHeight: 1.5 }}>{r.t}</div>
            </Card>
          ))}
        </div>

        {/* spacer for sticky CTA */}
        <div style={{ height: 90 }} />
      </div>

      {/* Sticky CTA */}
      <StickyCTA>
        <div style={{ display:'flex', gap: 8 }}>
          <Button variant="secondary" size="lg" onClick={() => {}}
            icon={<Icon.Bookmark size={16} color="var(--ink-2)" />}
            style={{ flexShrink: 0 }}
          >
            Simpan
          </Button>
          <Button variant="whatsapp" size="lg" full onClick={() => go('booking', { workerId: w.id })}
            icon={<Icon.Whatsapp size={18} />}
          >
            Hubungi via WhatsApp
          </Button>
        </div>
      </StickyCTA>
    </FrameContent>
  );
}

function SectionTitle({ children, right }) {
  return (
    <div style={{
      display:'flex', alignItems:'baseline', justifyContent:'space-between',
      margin: '20px 4px 10px',
    }}>
      <div style={{ fontSize: 13.5, fontWeight: 800, letterSpacing: -.1 }}>{children}</div>
      {right && (
        <button style={{
          background:'none', border:'none', color:'var(--primary)',
          fontSize: 11.5, fontWeight: 700, cursor:'pointer', fontFamily:'inherit',
        }}>{right}</button>
      )}
    </div>
  );
}

function StickyCTA({ children }) {
  return (
    <div style={{
      position:'absolute', left: 0, right: 0, bottom: 0,
      padding: '14px 16px 28px',
      background: 'linear-gradient(to top, #fff 60%, rgba(255,255,255,0))',
      zIndex: 35,
    }}>
      {children}
    </div>
  );
}

// ─────────────────── 6. BOOKING / CONTACT ───────────────────
function BookingScreen({ go, state, setState }) {
  const w = WORKERS.find(x => x.id === state.workerId) || WORKERS[0];
  const [time, setTime] = React.useState('Hari ini');
  const [addr, setAddr] = React.useState('Jl. Tebet Barat Dalam IV no. 12, RT 03');
  const defaultMsg = `Halo ${w.name}, saya butuh bantuan untuk AC bocor. Berdasarkan analisis Beresin, kemungkinan saluran drainase tersumbat. Lokasi saya sekitar ${w.distance} km dari Anda. Apakah bisa datang hari ini?`;
  const [msg, setMsg] = React.useState(defaultMsg);
  const [sent, setSent] = React.useState(false);

  return (
    <FrameContent>
      <ScreenHeader title="Konfirmasi Kebutuhan" subtitle="Sebelum hubungi tukang" onBack={() => go('worker', { workerId: w.id })} />

      <div style={{ padding: '0 18px' }}>
        {/* Worker pill */}
        <Card padding={12}>
          <div style={{ display:'flex', alignItems:'center', gap: 10 }}>
            <Avatar name={w.name} size={42} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display:'flex', alignItems:'center', gap: 4 }}>
                <span style={{ fontSize: 13.5, fontWeight: 800 }}>{w.name}</span>
                <Icon.Verified size={12} />
              </div>
              <div style={{ fontSize: 11.5, color:'var(--muted)' }}>{w.service} · {w.distance} km · ETA {w.eta}</div>
            </div>
            <Tag color="success">Aktif</Tag>
          </div>
        </Card>

        {/* AI summary */}
        <SectionTitle>Ringkasan dari AI</SectionTitle>
        <Card padding={14} style={{ background: 'var(--primary-50)', border: '1px solid #C5E2D6' }}>
          <div style={{ display:'flex', alignItems:'flex-start', gap: 8 }}>
            <Icon.Sparkle size={16} color="var(--primary-dark)" />
            <div style={{ fontSize: 12.5, color:'var(--primary-dark)', fontWeight: 700, lineHeight: 1.5 }}>
              Saluran drainase AC tersumbat · Estimasi {RP(75000)} – {RP(150000)} · 30–60 menit
            </div>
          </div>
        </Card>

        {/* Message */}
        <SectionTitle right={<span style={{ display:'inline-flex', alignItems:'center', gap: 3 }}><Icon.Edit size={12} color="var(--primary)" /> Edit</span>}>Pesan WhatsApp</SectionTitle>
        <Card padding={0} style={{ overflow:'hidden' }}>
          <textarea
            value={msg} onChange={e => setMsg(e.target.value)}
            style={{
              width:'100%', minHeight: 120, padding: 14,
              border:'none', resize:'none', outline:'none',
              fontFamily:'inherit', fontSize: 13, color:'var(--ink)',
              background:'#fff', lineHeight: 1.5,
            }}
          />
          <div style={{
            padding: '8px 12px', borderTop:'1px solid var(--line-2)',
            display:'flex', alignItems:'center', justifyContent:'space-between',
            background:'#FAFBFA',
          }}>
            <span style={{ fontSize: 11, color:'var(--muted)' }}>{msg.length} karakter</span>
            <button onClick={() => setMsg(defaultMsg)} style={{
              background:'none', border:'none', fontSize: 11.5, color:'var(--primary)',
              fontWeight: 700, cursor:'pointer', fontFamily:'inherit',
            }}>Reset</button>
          </div>
        </Card>

        {/* Time preference */}
        <SectionTitle>Waktu</SectionTitle>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap: 8 }}>
          {['Sekarang', 'Hari ini', 'Jadwalkan'].map(t => (
            <button key={t} onClick={() => setTime(t)} style={{
              background: time===t ? 'var(--ink)' : '#fff',
              color: time===t ? '#fff' : 'var(--ink)',
              border: '1px solid ' + (time===t ? 'var(--ink)' : 'var(--line)'),
              borderRadius: 12, padding: '12px 8px',
              fontSize: 12.5, fontWeight: 700, cursor:'pointer', fontFamily:'inherit',
            }}>{t}</button>
          ))}
        </div>

        {/* Address */}
        <SectionTitle right={<span style={{ display:'inline-flex', alignItems:'center', gap: 3 }}><Icon.Pin size={12} color="var(--primary)" /> Pin lokasi</span>}>Alamat</SectionTitle>
        <Card padding={0}>
          <div style={{ display:'flex', alignItems:'flex-start', gap: 10, padding: 12 }}>
            <div style={{
              width: 32, height: 32, borderRadius: 10,
              background: 'var(--primary-50)', color: 'var(--primary-dark)',
              display:'grid', placeItems:'center', flexShrink: 0,
            }}>
              <Icon.Pin size={16} color="var(--primary-dark)" />
            </div>
            <textarea
              value={addr} onChange={e => setAddr(e.target.value)}
              style={{
                flex:1, minHeight: 44, padding: 0, border:'none', resize:'none',
                outline:'none', fontFamily:'inherit', fontSize: 13, color:'var(--ink)',
                background:'transparent', lineHeight: 1.5,
              }}
            />
          </div>
        </Card>

        {/* Safety */}
        <Card padding={12} style={{
          marginTop: 14,
          background: 'linear-gradient(135deg, #FFF8EE 0%, #FFFCF6 100%)',
          border: '1px solid #FFE9C2',
        }}>
          <div style={{ display:'flex', gap: 10, alignItems:'flex-start' }}>
            <div style={{
              width: 32, height: 32, borderRadius: 10,
              background:'var(--accent-50)', color:'var(--accent-dark)',
              display:'grid', placeItems:'center', flexShrink: 0,
            }}>
              <Icon.Shield size={16} color="var(--accent-dark)" />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 12.5, fontWeight: 800, color:'#8A5A14' }}>Tips aman dari Beresin</div>
              <div style={{ fontSize: 11.5, color:'#8A5A14', marginTop: 4, lineHeight: 1.5 }}>
                Jangan bayar penuh sebelum pekerjaan dicek langsung. Konfirmasi harga lewat chat dulu.
              </div>
            </div>
          </div>
        </Card>

        <div style={{ height: 96 }} />
      </div>

      <StickyCTA>
        <Button variant="whatsapp" size="lg" full
          onClick={() => { setSent(true); setTimeout(() => go('history'), 1200); }}
          icon={<Icon.Whatsapp size={20} />}
          iconRight={<Icon.ArrowRight size={18} color="#fff" />}
        >
          {sent ? 'Membuka WhatsApp…' : 'Kirim ke WhatsApp'}
        </Button>
      </StickyCTA>
    </FrameContent>
  );
}

// ─────────────────── 7. HISTORY / DASHBOARD ───────────────────
function HistoryScreen({ go }) {
  return (
    <FrameContent>
      <ScreenHeader title="Riwayat" subtitle="Layanan kamu" />
      <div style={{ padding: '0 18px' }}>
        {/* Active request */}
        <SectionTitle right="Detail">Permintaan Aktif</SectionTitle>
        <Card padding={0} style={{ overflow:'hidden', border:'1.5px solid var(--accent)' }}>
          <div style={{
            padding:'7px 14px',
            background:'linear-gradient(90deg, var(--accent), var(--accent-dark))',
            color:'#fff', fontSize: 11, fontWeight: 800, letterSpacing: .4,
            display:'flex', alignItems:'center', gap: 6,
          }}>
            <span style={{
              width: 7, height: 7, borderRadius: 4, background:'#fff',
              animation:'pulseSoft 1.4s ease-in-out infinite',
            }}/>
            MENUNGGU RESPON TEKNISI
          </div>
          <div style={{ padding: 14 }}>
            <div style={{ display:'flex', alignItems:'center', gap: 12 }}>
              <div style={{
                width: 48, height: 48, borderRadius: 14, overflow:'hidden', position:'relative',
                flexShrink: 0,
              }}>
                <MockACPhoto />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13.5, fontWeight: 800 }}>AC bocor — Pak Rudi</div>
                <div style={{ fontSize: 11.5, color:'var(--muted)' }}>Dikirim 2 menit lalu · Estimasi {RP(75000)}–{RP(150000)}</div>
              </div>
            </div>
            <div style={{
              marginTop: 12, display:'flex', gap: 4, alignItems:'center',
            }}>
              {['Terkirim', 'Dibaca', 'Dikonfirmasi', 'Selesai'].map((s, i) => (
                <React.Fragment key={s}>
                  <div style={{ flex: 1, textAlign:'center' }}>
                    <div style={{
                      height: 4, borderRadius: 2,
                      background: i <= 1 ? 'var(--accent)' : 'var(--line)',
                    }}/>
                    <div style={{ fontSize: 10, fontWeight: 700, marginTop: 4, color: i <= 1 ? 'var(--ink)' : 'var(--muted)' }}>{s}</div>
                  </div>
                </React.Fragment>
              ))}
            </div>
            <div style={{ display:'flex', gap: 8, marginTop: 12 }}>
              <Button variant="secondary" size="sm" full
                onClick={() => go('worker', { workerId: 'rudi' })}
              >Lihat Tukang</Button>
              <Button variant="whatsapp" size="sm" full
                icon={<Icon.Whatsapp size={14} />}
              >Buka Chat</Button>
            </div>
          </div>
        </Card>

        {/* Past services */}
        <SectionTitle right="Semua">Layanan Lalu</SectionTitle>
        <Card padding={4}>
          {[
            { t:'Cuci AC',          who:'Pak Rudi',   when:'12 Apr 2026', price:'Rp95.000',  done: true,  rated: true,  stars: 5 },
            { t:'Bersih rumah 2BR', who:'Bu Sari',    when:'2 Apr 2026',  price:'Rp220.000', done: true,  rated: false },
            { t:'Perbaikan pipa',   who:'Pak Dedi',   when:'14 Mar 2026', price:'Rp140.000', done: true,  rated: true,  stars: 4 },
          ].map((it, i, arr) => (
            <div key={i} style={{
              display:'flex', alignItems:'center', gap: 12, padding: '12px 12px',
              borderBottom: i < arr.length-1 ? '1px solid var(--line-2)' : 'none',
            }}>
              <ServiceIcon kind={it.t.includes('AC') ? 'AC' : it.t.includes('pipa') ? 'Plumbing' : 'Cleaning'} size={36} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 700 }}>{it.t}</div>
                <div style={{ fontSize: 11, color:'var(--muted)' }}>{it.who} · {it.when}</div>
                {!it.rated && (
                  <div style={{
                    marginTop: 6, display:'inline-flex', alignItems:'center', gap: 4,
                    padding: '3px 8px', borderRadius: 6,
                    background:'var(--accent-50)', color:'var(--accent-dark)',
                    fontSize: 10.5, fontWeight: 800,
                  }}>
                    <Icon.Star size={11} color="var(--accent-dark)" /> Beri rating?
                  </div>
                )}
                {it.rated && (
                  <div style={{ marginTop: 4, display:'flex', gap: 1 }}>
                    {[1,2,3,4,5].map(n => <Icon.Star key={n} size={10} color={n<=it.stars?'#F59E3C':'#E5EAE5'}/>)}
                  </div>
                )}
              </div>
              <div style={{ fontSize: 12, fontWeight: 800, textAlign:'right', flexShrink: 0 }}>{it.price}</div>
            </div>
          ))}
        </Card>

        {/* Saved workers */}
        <SectionTitle right="Lihat semua">Tukang Tersimpan</SectionTitle>
        <div style={{ display:'flex', gap: 10, overflowX:'auto', paddingBottom: 4, margin:'0 -18px', padding: '0 18px 6px' }} className="noscroll">
          {WORKERS.slice(0,3).map(w => (
            <div key={w.id} onClick={() => go('worker', { workerId: w.id })} style={{
              minWidth: 130, background:'#fff', borderRadius: 16, padding: 12, cursor:'pointer',
              border:'1px solid rgba(15,31,26,.05)', textAlign:'center',
              boxShadow: '0 4px 12px -8px rgba(15,31,26,.1)',
              flexShrink: 0,
            }}>
              <Avatar name={w.name} size={48} />
              <div style={{ fontSize: 12.5, fontWeight: 800, marginTop: 8, display:'flex', alignItems:'center', justifyContent:'center', gap: 3 }}>
                {w.name.split(' ').slice(0,2).join(' ')}
                <Icon.Verified size={11} />
              </div>
              <div style={{ fontSize: 10.5, color:'var(--muted)' }}>{w.service}</div>
              <div style={{ fontSize: 11, fontWeight: 700, marginTop: 4, color:'var(--ink-2)', display:'inline-flex', alignItems:'center', gap: 3 }}>
                <Icon.Star size={11} /> {w.rating}
              </div>
            </div>
          ))}
        </div>

        <div style={{ height: 12 }} />
      </div>
    </FrameContent>
  );
}

// ─────────────────── 8. PROFILE ───────────────────
function ProfileScreen({ go }) {
  return (
    <FrameContent>
      <div style={{
        background: 'linear-gradient(180deg, #0E8E6C 0%, #0A6E54 100%)',
        color:'#fff', padding: '54px 18px 60px',
        borderBottomLeftRadius: 32, borderBottomRightRadius: 32,
        position:'relative', overflow:'hidden',
      }}>
        <div style={{
          position:'absolute', top:-50, right:-50, width: 180, height: 180, borderRadius:'50%',
          background:'radial-gradient(circle, rgba(255,255,255,.10), transparent 60%)',
        }} />
        <div style={{ display:'flex', alignItems:'center', gap: 14, position:'relative' }}>
          <Avatar name="Wira S." size={64} palette={[['#FFD89B','#F59E3C']]} />
          <div>
            <div style={{ fontSize: 18, fontWeight: 800 }}>Wira Saputra</div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,.75)' }}>+62 812-3456-7890</div>
            <div style={{
              marginTop: 6, display:'inline-flex', alignItems:'center', gap: 4,
              padding: '3px 8px', borderRadius: 6, background:'rgba(255,255,255,.18)',
              fontSize: 10.5, fontWeight: 700,
            }}>
              <Icon.Sparkle size={10} color="#FFD89B" /> WARGA TEBET
            </div>
          </div>
        </div>
      </div>

      <div style={{ padding: '0 18px', marginTop: -42 }}>
        <Card padding={14}>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap: 1, background:'var(--line)', borderRadius: 12, overflow:'hidden' }}>
            {[
              { l:'Layanan', v:'12' },
              { l:'Tukang', v:'4' },
              { l:'Hemat', v:'~Rp420rb' },
            ].map((s,i) => (
              <div key={i} style={{ background:'#fff', padding: 12, textAlign:'center' }}>
                <div style={{ fontSize: 16, fontWeight: 800 }}>{s.v}</div>
                <div style={{ fontSize: 11, color:'var(--muted)' }}>{s.l}</div>
              </div>
            ))}
          </div>
        </Card>

        <SectionTitle>Akun</SectionTitle>
        <Card padding={4}>
          {[
            { Icn:Icon.Pin,    t:'Alamat tersimpan',     d:'2 alamat' },
            { Icn:Icon.Coin,   t:'Riwayat harga',        d:'Lihat estimasi vs aktual' },
            { Icn:Icon.Bookmark, t:'Tukang tersimpan',  d:'4 tukang' },
            { Icn:Icon.Bell,   t:'Notifikasi',           d:'WhatsApp & in-app' },
            { Icn:Icon.Shield, t:'Keamanan & privasi',   d:'PIN, verifikasi nomor' },
          ].map((r, i, arr) => (
            <div key={i} style={{
              display:'flex', alignItems:'center', gap: 12, padding:'12px 12px',
              borderBottom: i < arr.length-1 ? '1px solid var(--line-2)' : 'none',
              cursor:'pointer',
            }}>
              <div style={{
                width: 32, height: 32, borderRadius: 10,
                background:'var(--bg)', color:'var(--ink-2)',
                display:'grid', placeItems:'center',
              }}>
                <r.Icn size={16} color="var(--ink-2)" />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 700 }}>{r.t}</div>
                <div style={{ fontSize: 11, color:'var(--muted)' }}>{r.d}</div>
              </div>
              <Icon.ChevronRight size={16} color="var(--muted)" />
            </div>
          ))}
        </Card>

        <SectionTitle>Bantuan</SectionTitle>
        <Card padding={4}>
          {[
            { Icn:Icon.Sparkle, t:'Kenapa Beresin?', d:'Cara kerja AI & tukang' },
            { Icn:Icon.Phone,   t:'Hubungi support', d:'Senin–Sabtu 09–20' },
          ].map((r, i, arr) => (
            <div key={i} style={{
              display:'flex', alignItems:'center', gap: 12, padding:'12px 12px',
              borderBottom: i < arr.length-1 ? '1px solid var(--line-2)' : 'none',
            }}>
              <div style={{
                width: 32, height: 32, borderRadius: 10,
                background:'var(--bg)', color:'var(--ink-2)',
                display:'grid', placeItems:'center',
              }}>
                <r.Icn size={16} color="var(--ink-2)" />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 700 }}>{r.t}</div>
                <div style={{ fontSize: 11, color:'var(--muted)' }}>{r.d}</div>
              </div>
              <Icon.ChevronRight size={16} color="var(--muted)" />
            </div>
          ))}
        </Card>

        <div style={{ textAlign:'center', fontSize: 11, color:'var(--muted)', margin: '20px 0 4px' }}>
          Beresin · v1.0 hackathon · made with care in Jakarta
        </div>
      </div>
    </FrameContent>
  );
}

Object.assign(window, {
  WORKERS, ResultScreen, WorkersScreen, WorkerProfileScreen, BookingScreen,
  HistoryScreen, ProfileScreen, Stars, SectionTitle, StickyCTA, WorkerCard,
});
