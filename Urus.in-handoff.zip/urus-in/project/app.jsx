// Beresin app — router, bottom nav, Tweaks panel
const { useState, useEffect, useRef } = React;

const PALETTES = {
  'Hijau Beresin': { primary:'#0E8E6C', dark:'#0A6E54', tint:'#ECF7F2', tint2:'#D8EFE6', accent:'#F59E3C', accentDark:'#E37614', accent50:'#FFF4E5' },
  'Biru Tepercaya': { primary:'#1E6FE0', dark:'#114BA1', tint:'#E8F0FE', tint2:'#D2E1FB', accent:'#F59E3C', accentDark:'#E37614', accent50:'#FFF4E5' },
  'Teal Hangat':   { primary:'#0D8B8B', dark:'#076868', tint:'#E5F3F3', tint2:'#CDE8E8', accent:'#FF7849', accentDark:'#D55B2E', accent50:'#FFEFE5' },
};

function applyPalette(p) {
  const r = document.documentElement.style;
  r.setProperty('--primary', p.primary);
  r.setProperty('--primary-dark', p.dark);
  r.setProperty('--primary-50', p.tint);
  r.setProperty('--primary-100', p.tint2);
  r.setProperty('--accent', p.accent);
  r.setProperty('--accent-dark', p.accentDark);
  r.setProperty('--accent-50', p.accent50);
}

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "palette": "Hijau Beresin",
  "showFrame": true,
  "darkMode": false
}/*EDITMODE-END*/;

function App() {
  const [tweaks, setTweak] = (window.useTweaks || ((d) => [d, () => {}]))(TWEAK_DEFAULTS);
  const [route, setRoute] = useState('home');
  const [state, setState] = useState({ photo: null, desc: '', cat: 'AC', urgency: 'Segera', workerId: 'rudi' });
  const [history, setHistory] = useState(['home']);

  // apply palette
  useEffect(() => {
    applyPalette(PALETTES[tweaks.palette] || PALETTES['Hijau Beresin']);
  }, [tweaks.palette]);

  const go = (r, patch) => {
    if (patch) setState(s => ({ ...s, ...patch }));
    setRoute(r);
    setHistory(h => [...h, r]);
  };

  // Map nav-tab keys to routes
  const navKey = (() => {
    if (route === 'home') return 'home';
    if (route === 'upload' || route === 'analyzing' || route === 'result') return 'check';
    if (route === 'workers' || route === 'worker' || route === 'booking') return 'workers';
    if (route === 'history') return 'history';
    if (route === 'profile') return 'profile';
    return 'home';
  })();

  const onNav = (k) => {
    if (k === 'home') go('home');
    if (k === 'check') go('upload');
    if (k === 'workers') go('workers');
    if (k === 'history') go('history');
    if (k === 'profile') go('profile');
  };

  let screen;
  switch (route) {
    case 'home':      screen = <HomeScreen go={go} />; break;
    case 'upload':    screen = <UploadScreen go={go} state={state} setState={setState} />; break;
    case 'analyzing': screen = <AnalyzingScreen go={go} />; break;
    case 'result':    screen = <ResultScreen go={go} state={state} />; break;
    case 'workers':   screen = <WorkersScreen go={go} />; break;
    case 'worker':    screen = <WorkerProfileScreen go={go} state={state} />; break;
    case 'booking':   screen = <BookingScreen go={go} state={state} setState={setState} />; break;
    case 'history':   screen = <HistoryScreen go={go} />; break;
    case 'profile':   screen = <ProfileScreen go={go} />; break;
    default:          screen = <HomeScreen go={go} />;
  }

  // hide bottom nav on certain immersive screens
  const showNav = !['analyzing'].includes(route);

  const FrameWrapper = ({ children }) => {
    if (!tweaks.showFrame) {
      return (
        <div style={{
          width: 402, height: 874, borderRadius: 32, overflow: 'hidden',
          position: 'relative', background: 'var(--bg)',
          boxShadow: '0 30px 80px -20px rgba(0,0,0,.35)',
        }}>
          {children}
        </div>
      );
    }
    return (
      <IOSDevice width={402} height={874} dark={false}>
        {children}
      </IOSDevice>
    );
  };

  // expose route setter for PPTX export
  useEffect(() => { window.__setRoute = setRoute; }, []);

  return (
    <div id="slide-root" style={{ display:'flex', alignItems:'center', justifyContent:'center', gap: 24, flexWrap:'wrap', padding: 20, background: 'transparent' }}>
      <FrameWrapper>
        <div data-screen-label={routeLabel(route)} style={{ position:'absolute', inset: 0 }}>
          <div key={route} className="br-screen" style={{ position:'absolute', inset: 0 }}>
            {screen}
          </div>
          {showNav && <BottomNav active={navKey} onChange={onNav} />}
        </div>
      </FrameWrapper>

      <TweaksUI tweaks={tweaks} setTweak={setTweak} go={go} route={route} />
    </div>
  );
}

function routeLabel(r) {
  const map = {
    home:'01 Home', upload:'02 Upload', analyzing:'03 Analyzing',
    result:'04 AI Result', workers:'05 Workers', worker:'06 Worker Profile',
    booking:'07 Booking', history:'08 History', profile:'09 Profile',
  };
  return map[r] || r;
}

// ─────────────────── Tweaks panel ───────────────────
function TweaksUI({ tweaks, setTweak, go, route }) {
  const TP = window.TweaksPanel;
  const TS = window.TweakSection;
  const TR = window.TweakRadio;
  const TT = window.TweakToggle;
  const TC = window.TweakColor;
  const TB = window.TweakButton;
  const TSel = window.TweakSelect;

  if (!TP) return null;

  const screens = [
    { v:'home',      l:'Home' },
    { v:'upload',    l:'Upload Foto' },
    { v:'analyzing', l:'AI Lagi Mikir' },
    { v:'result',    l:'Hasil AI' },
    { v:'workers',   l:'Daftar Tukang' },
    { v:'worker',    l:'Profil Tukang' },
    { v:'booking',   l:'Booking / WA' },
    { v:'history',   l:'Riwayat' },
    { v:'profile',   l:'Profil User' },
  ];

  return (
    <TP title="Tweaks" subtitle="Beresin prototype">
      <TS title="Jump to screen">
        <TSel value={route} onChange={v => go(v)} options={screens.map(s => ({ value: s.v, label: s.l }))} />
      </TS>

      <TS title="Palette">
        <TR
          value={tweaks.palette}
          onChange={v => setTweak('palette', v)}
          options={Object.keys(PALETTES).map(name => ({ value: name, label: name }))}
        />
      </TS>

      <TS title="Frame">
        <TT label="Tampilkan iPhone frame" value={tweaks.showFrame} onChange={v => setTweak('showFrame', v)} />
      </TS>

      <TS title="Demo flow">
        <TB onClick={() => go('home')}>Reset ke Beranda</TB>
        <div style={{ height: 6 }} />
        <TB onClick={() => go('upload')}>Mulai dari Upload</TB>
      </TS>
    </TP>
  );
}

ReactDOM.createRoot(document.getElementById('app-root')).render(<App />);
