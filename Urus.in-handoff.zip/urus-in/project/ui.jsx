// UI primitives for Beresin

const beresinTheme = {
  primary: 'var(--primary)',
  primaryDark: 'var(--primary-dark)',
  accent: 'var(--accent)',
  ink: 'var(--ink)',
  ink2: 'var(--ink-2)',
  muted: 'var(--muted)',
  surface: 'var(--surface)',
  bg: 'var(--bg)',
  line: 'var(--line)',
};

// ─────────────────── Avatar (initials with branded gradient) ───────────────────
function Avatar({ name = 'X', size = 44, palette }) {
  const palettes = palette || [
    ['#0E8E6C', '#1FB18A'],
    ['#F59E3C', '#FFC178'],
    ['#3D6FE0', '#7BA3F2'],
    ['#A8559E', '#D88BC9'],
    ['#1F8A5B', '#5BC196'],
    ['#D6553B', '#F08C66'],
  ];
  const i = (name.charCodeAt(0) + name.length) % palettes.length;
  const [a, b] = palettes[i];
  const initials = name.split(' ').map(s => s[0]).join('').slice(0,2).toUpperCase();
  return (
    <div style={{
      width: size, height: size, borderRadius: size/2,
      background: `linear-gradient(135deg, ${a}, ${b})`,
      color: '#fff', fontWeight: 700, fontSize: size*0.38,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      flexShrink: 0,
      boxShadow: 'inset 0 -2px 6px rgba(0,0,0,.12), inset 0 1px 0 rgba(255,255,255,.3)',
    }}>{initials}</div>
  );
}

// ─────────────────── Pill / Chip ───────────────────
function Chip({ children, active, onClick, icon, variant = 'default', style = {} }) {
  const variants = {
    default: {
      bg: active ? 'var(--ink)' : '#fff',
      color: active ? '#fff' : 'var(--ink)',
      border: active ? 'transparent' : '1px solid var(--line)',
    },
    primary: {
      bg: active ? 'var(--primary)' : 'var(--primary-50)',
      color: active ? '#fff' : 'var(--primary-dark)',
      border: 'transparent',
    },
    soft: {
      bg: active ? '#fff' : 'transparent',
      color: 'var(--ink-2)',
      border: '1px solid ' + (active ? 'var(--ink)' : 'rgba(0,0,0,.08)'),
    }
  };
  const v = variants[variant];
  return (
    <button onClick={onClick} style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '8px 14px', borderRadius: 999,
      background: v.bg, color: v.color,
      border: typeof v.border === 'string' && v.border.startsWith('1px') ? v.border : 'none',
      outline: typeof v.border === 'string' && v.border.startsWith('1px') ? 'none' : `1px solid ${v.border}`,
      fontSize: 13, fontWeight: 600,
      fontFamily: 'inherit', cursor: 'pointer',
      whiteSpace: 'nowrap',
      transition: 'all .18s ease',
      ...style,
    }}>
      {icon}
      {children}
    </button>
  );
}

// ─────────────────── Button ───────────────────
function Button({ children, onClick, variant='primary', size='md', icon, iconRight, full, style={} }) {
  const sizes = {
    sm: { padding: '10px 14px', fontSize: 13, radius: 12 },
    md: { padding: '14px 18px', fontSize: 15, radius: 14 },
    lg: { padding: '17px 22px', fontSize: 16, radius: 18 },
  };
  const s = sizes[size];
  const variants = {
    primary: {
      bg: 'var(--primary)', color: '#fff',
      shadow: '0 6px 18px -6px rgba(14,142,108,.6), inset 0 1px 0 rgba(255,255,255,.18)',
      border: 'none',
    },
    accent: {
      bg: 'var(--accent)', color: '#fff',
      shadow: '0 6px 18px -6px rgba(245,158,60,.65), inset 0 1px 0 rgba(255,255,255,.25)',
      border: 'none',
    },
    secondary: {
      bg: '#fff', color: 'var(--ink)',
      shadow: '0 1px 0 rgba(0,0,0,.04)',
      border: '1px solid var(--line)',
    },
    ghost: {
      bg: 'transparent', color: 'var(--ink-2)',
      shadow: 'none',
      border: '1px solid transparent',
    },
    whatsapp: {
      bg: '#25D366', color: '#fff',
      shadow: '0 6px 18px -6px rgba(37,211,102,.6), inset 0 1px 0 rgba(255,255,255,.25)',
      border: 'none',
    }
  };
  const v = variants[variant];
  return (
    <button onClick={onClick} style={{
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
      padding: s.padding, borderRadius: s.radius,
      background: v.bg, color: v.color, border: v.border,
      boxShadow: v.shadow,
      fontSize: s.fontSize, fontWeight: 700, letterSpacing: -.1,
      fontFamily: 'inherit', cursor: 'pointer',
      width: full ? '100%' : undefined,
      transition: 'transform .12s ease, box-shadow .18s ease',
      ...style,
    }}
    onMouseDown={e => e.currentTarget.style.transform = 'scale(.98)'}
    onMouseUp={e => e.currentTarget.style.transform = ''}
    onMouseLeave={e => e.currentTarget.style.transform = ''}
    >
      {icon}
      <span>{children}</span>
      {iconRight}
    </button>
  );
}

// ─────────────────── Card ───────────────────
function Card({ children, style = {}, padding = 16, onClick }) {
  return (
    <div onClick={onClick} style={{
      background: '#fff', borderRadius: 20, padding,
      boxShadow: '0 1px 0 rgba(15,31,26,.04), 0 8px 24px -16px rgba(15,31,26,.12)',
      border: '1px solid rgba(15,31,26,.04)',
      cursor: onClick ? 'pointer' : undefined,
      ...style,
    }}>{children}</div>
  );
}

// ─────────────────── Tag (small badge) ───────────────────
function Tag({ children, color='primary', icon, style={} }) {
  const palettes = {
    primary: { bg: 'var(--primary-50)', fg: 'var(--primary-dark)' },
    accent: { bg: 'var(--accent-50)', fg: 'var(--accent-dark)' },
    neutral: { bg: '#F1F4F1', fg: 'var(--ink-2)' },
    danger: { bg: '#FBE9E2', fg: '#A93B22' },
    blue: { bg: '#E5EEFB', fg: '#2A4FA0' },
    success: { bg: '#E5F5EB', fg: '#0F7A45' },
  };
  const p = palettes[color] || palettes.primary;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: '4px 9px', borderRadius: 8,
      background: p.bg, color: p.fg,
      fontSize: 11, fontWeight: 700, letterSpacing: .1,
      whiteSpace: 'nowrap',
      ...style,
    }}>
      {icon}
      {children}
    </span>
  );
}

// ─────────────────── Header (in-frame) ───────────────────
function ScreenHeader({ title, subtitle, onBack, right, dark=false }) {
  return (
    <div style={{
      padding: '54px 18px 14px',
      display: 'flex', alignItems: 'flex-start', gap: 10,
      background: dark ? 'transparent' : 'transparent',
    }}>
      {onBack && (
        <button onClick={onBack} aria-label="Back" style={{
          width: 38, height: 38, borderRadius: 19,
          background: dark ? 'rgba(255,255,255,.14)' : '#fff',
          border: dark ? 'none' : '1px solid var(--line)',
          color: dark ? '#fff' : 'var(--ink)',
          display: 'grid', placeItems: 'center', cursor: 'pointer',
          flexShrink: 0,
          boxShadow: dark ? 'none' : '0 1px 0 rgba(0,0,0,.03)',
        }}>
          <Icon.ChevronLeft size={20} />
        </button>
      )}
      <div style={{ flex: 1, paddingTop: 4 }}>
        {subtitle && <div style={{
          fontSize: 12, fontWeight: 600, letterSpacing: .4,
          textTransform: 'uppercase',
          color: dark ? 'rgba(255,255,255,.6)' : 'var(--muted)',
          marginBottom: 2,
        }}>{subtitle}</div>}
        <div style={{
          fontSize: 22, fontWeight: 800, letterSpacing: -.4,
          color: dark ? '#fff' : 'var(--ink)',
        }}>{title}</div>
      </div>
      {right && <div style={{ flexShrink: 0 }}>{right}</div>}
    </div>
  );
}

// ─────────────────── Bottom nav ───────────────────
function BottomNav({ active, onChange }) {
  const items = [
    { key: 'home',    label: 'Beranda',     Icon: Icon.NavHome },
    { key: 'workers', label: 'Tukang',      Icon: Icon.NavWorkers },
    { key: 'check',   label: 'Cek Masalah', Icon: Icon.NavCamera, fab: true },
    { key: 'history', label: 'Riwayat',     Icon: Icon.NavHistory },
    { key: 'profile', label: 'Profil',      Icon: Icon.NavProfile },
  ];
  return (
    <div style={{
      position: 'absolute', left: 0, right: 0, bottom: 0,
      paddingBottom: 28,
      background: 'linear-gradient(to top, #fff 70%, rgba(255,255,255,0))',
      pointerEvents: 'none', zIndex: 40,
    }}>
      <div style={{
        margin: '0 12px',
        background: '#fff',
        borderRadius: 26,
        boxShadow: '0 8px 24px -10px rgba(15,31,26,.18), 0 1px 0 rgba(15,31,26,.05)',
        border: '1px solid rgba(15,31,26,.04)',
        padding: '10px 8px',
        display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)',
        pointerEvents: 'auto',
      }}>
        {items.map(({ key, label, Icon: I, fab }) => {
          const isActive = active === key;
          if (fab) {
            return (
              <button key={key} onClick={() => onChange(key)} style={{
                background: 'none', border: 'none', cursor: 'pointer',
                display: 'flex', flexDirection: 'column', alignItems: 'center',
                gap: 4, padding: 0,
                fontFamily: 'inherit',
              }}>
                <div style={{
                  width: 48, height: 48, borderRadius: 24,
                  background: isActive
                    ? 'linear-gradient(135deg, var(--accent) 0%, var(--accent-dark) 100%)'
                    : 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)',
                  display: 'grid', placeItems: 'center',
                  marginTop: -22,
                  boxShadow: '0 8px 18px -6px rgba(14,142,108,.55), inset 0 1px 0 rgba(255,255,255,.25)',
                }}>
                  <I size={24} color="#fff" />
                </div>
                <div style={{
                  fontSize: 10.5, fontWeight: 700,
                  color: isActive ? 'var(--accent-dark)' : 'var(--primary-dark)',
                }}>{label}</div>
              </button>
            );
          }
          return (
            <button key={key} onClick={() => onChange(key)} style={{
              background: 'none', border: 'none', cursor: 'pointer',
              display: 'flex', flexDirection: 'column', alignItems: 'center',
              gap: 5, padding: '6px 0',
              fontFamily: 'inherit',
            }}>
              <I size={22} color={isActive ? 'var(--primary)' : 'var(--muted)'} filled={isActive} />
              <div style={{
                fontSize: 10.5, fontWeight: isActive ? 700 : 500,
                color: isActive ? 'var(--primary)' : 'var(--muted)',
              }}>{label}</div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ─────────────────── Status bar spacer / safe top ───────────────────
function FrameContent({ children, withNav=true, bg='var(--bg)', noTopPad=false }) {
  return (
    <div style={{
      position: 'absolute', inset: 0,
      background: bg,
      overflow: 'hidden',
      borderRadius: 48,
    }}>
      <div className="noscroll" style={{
        position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
        overflowY: 'auto', overflowX: 'hidden',
        paddingTop: noTopPad ? 0 : 0,
        paddingBottom: withNav ? 110 : 40,
      }}>
        {children}
      </div>
    </div>
  );
}

// ─────────────────── Service icon tile ───────────────────
function ServiceIcon({ kind, size=48, bg }) {
  const map = {
    AC:       { Icn: Icon.AC,    bg: '#E5F0FB', fg: '#2A4FA0' },
    Plumbing: { Icn: Icon.Pipe,  bg: '#E0F2EE', fg: '#0E8E6C' },
    Listrik:  { Icn: Icon.Plug,  bg: '#FFF1D9', fg: '#B57008' },
    Cleaning: { Icn: Icon.Broom, bg: '#F1ECFA', fg: '#6B4FBF' },
    Kebun:    { Icn: Icon.Leaf,  bg: '#E6F3DC', fg: '#3F7B1F' },
    Lainnya:  { Icn: Icon.Wrench,bg: '#F2F0EC', fg: '#4A4036' },
  };
  const c = map[kind] || map.Lainnya;
  return (
    <div style={{
      width: size, height: size, borderRadius: size*0.32,
      background: bg || c.bg, color: c.fg,
      display: 'grid', placeItems: 'center',
      flexShrink: 0,
    }}>
      <c.Icn size={size*0.5} color={c.fg} />
    </div>
  );
}

Object.assign(window, { Avatar, Chip, Button, Card, Tag, ScreenHeader, BottomNav, FrameContent, ServiceIcon, beresinTheme });
