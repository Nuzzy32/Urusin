// Inline SVG icons for Beresin

const Icon = {
  Camera: ({ size=22, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M3 8a2 2 0 0 1 2-2h2.6l1.4-2h6l1.4 2H19a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8Z" stroke={color} strokeWidth="1.6"/>
      <circle cx="12" cy="13" r="3.6" stroke={color} strokeWidth="1.6"/>
    </svg>
  ),
  Image: ({ size=22, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <rect x="3" y="4" width="18" height="16" rx="3" stroke={color} strokeWidth="1.6"/>
      <circle cx="8.5" cy="9.5" r="1.5" fill={color}/>
      <path d="m4 17 5-5 4 4 3-3 4 4" stroke={color} strokeWidth="1.6" strokeLinejoin="round"/>
    </svg>
  ),
  Sparkle: ({ size=18, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 3.5 13.6 9l5.5 1.6L13.6 12l-1.6 5.5L10.4 12 4.9 10.5 10.4 9 12 3.5Z" fill={color}/>
      <path d="M19 15.5 19.7 18l2.5.7-2.5.8L19 22l-.8-2.5-2.5-.7 2.5-.7L19 15.5Z" fill={color} opacity=".7"/>
    </svg>
  ),
  ArrowRight: ({ size=18, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M5 12h14m-5-5 5 5-5 5" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  ChevronLeft: ({ size=22, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="m15 6-6 6 6 6" stroke={color} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  ChevronRight: ({ size=18, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="m9 6 6 6-6 6" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Star: ({ size=14, color='#F59E3C', filled=true }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={filled?color:'none'} stroke={color} strokeWidth="1.6">
      <path d="m12 3 2.85 5.78L21 9.7l-4.5 4.39L17.7 21 12 17.77 6.3 21l1.2-6.91L3 9.7l6.15-.92L12 3Z" strokeLinejoin="round"/>
    </svg>
  ),
  Check: ({ size=16, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="m5 12 5 5L20 7" stroke={color} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Shield: ({ size=14, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 3 4 6v6c0 4.5 3.2 8.4 8 9 4.8-.6 8-4.5 8-9V6l-8-3Z" stroke={color} strokeWidth="1.6" strokeLinejoin="round"/>
      <path d="m9 12 2 2 4-4" stroke={color} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Pin: ({ size=14, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 22s7-7.5 7-12a7 7 0 1 0-14 0c0 4.5 7 12 7 12Z" stroke={color} strokeWidth="1.6" strokeLinejoin="round"/>
      <circle cx="12" cy="10" r="2.6" stroke={color} strokeWidth="1.6"/>
    </svg>
  ),
  Clock: ({ size=14, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="9" stroke={color} strokeWidth="1.6"/>
      <path d="M12 7v5l3 2" stroke={color} strokeWidth="1.6" strokeLinecap="round"/>
    </svg>
  ),
  Coin: ({ size=14, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="9" stroke={color} strokeWidth="1.6"/>
      <path d="M14.5 9h-3.4a1.6 1.6 0 0 0 0 3.2h1.8a1.6 1.6 0 0 1 0 3.2H9.5M12 7.5v9" stroke={color} strokeWidth="1.6" strokeLinecap="round"/>
    </svg>
  ),
  Phone: ({ size=16, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M5 4h3l2 5-2.5 1.5a11 11 0 0 0 6 6L15 14l5 2v3a2 2 0 0 1-2 2A15 15 0 0 1 3 6a2 2 0 0 1 2-2Z" stroke={color} strokeWidth="1.6" strokeLinejoin="round"/>
    </svg>
  ),
  Whatsapp: ({ size=18, color='#fff' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
      <path d="M12.04 2C6.6 2 2.18 6.42 2.18 11.86c0 1.92.55 3.79 1.6 5.42L2 22l4.86-1.27a9.85 9.85 0 0 0 5.18 1.47h.004c5.44 0 9.86-4.42 9.86-9.86 0-2.63-1.02-5.1-2.88-6.96A9.84 9.84 0 0 0 12.04 2Zm5.86 14.13c-.25.7-1.45 1.32-2.02 1.4-.51.07-1.16.1-1.87-.12-.43-.13-.99-.32-1.7-.62-2.99-1.29-4.94-4.31-5.09-4.51-.15-.2-1.21-1.61-1.21-3.07 0-1.46.77-2.18 1.04-2.48.27-.3.59-.37.79-.37.2 0 .39 0 .56.01.18.01.42-.07.66.5.25.6.84 2.06.91 2.21.07.15.12.32.02.52-.1.2-.15.32-.3.5-.15.18-.31.4-.45.54-.15.15-.3.31-.13.61.17.3.76 1.26 1.64 2.04 1.13 1.01 2.08 1.32 2.38 1.47.3.15.47.13.65-.07.18-.2.75-.87.95-1.17.2-.3.4-.25.67-.15.27.1 1.72.81 2.02.96.3.15.5.22.57.35.07.13.07.74-.18 1.45Z"/>
    </svg>
  ),
  Search: ({ size=20, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <circle cx="11" cy="11" r="7" stroke={color} strokeWidth="1.8"/>
      <path d="m20 20-3.5-3.5" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
    </svg>
  ),
  Bell: ({ size=20, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M6 16V11a6 6 0 1 1 12 0v5l1.5 2H4.5L6 16Z" stroke={color} strokeWidth="1.6" strokeLinejoin="round"/>
      <path d="M10 21a2 2 0 0 0 4 0" stroke={color} strokeWidth="1.6" strokeLinecap="round"/>
    </svg>
  ),
  Plus: ({ size=20, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 5v14M5 12h14" stroke={color} strokeWidth="2.2" strokeLinecap="round"/>
    </svg>
  ),
  Send: ({ size=18, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M3 11 21 3l-7 18-3-8-8-2Z" stroke={color} strokeWidth="1.6" strokeLinejoin="round"/>
    </svg>
  ),
  Edit: ({ size=16, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M4 20h4l11-11-4-4L4 16v4Z" stroke={color} strokeWidth="1.6" strokeLinejoin="round"/>
      <path d="m13 5 4 4" stroke={color} strokeWidth="1.6"/>
    </svg>
  ),
  Bookmark: ({ size=18, color='currentColor', filled=false }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={filled?color:'none'}>
      <path d="M6 4h12v17l-6-4-6 4V4Z" stroke={color} strokeWidth="1.6" strokeLinejoin="round"/>
    </svg>
  ),
  Bolt: ({ size=18, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
      <path d="M13 2 4 14h6l-1 8 9-12h-6l1-8Z"/>
    </svg>
  ),
  // Service category icons
  AC: ({ size=22, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <rect x="2.5" y="5" width="19" height="9" rx="2.2" stroke={color} strokeWidth="1.6"/>
      <path d="M2.5 10h19" stroke={color} strokeWidth="1.6"/>
      <path d="M7 17v1m5-1v3m5-3v1" stroke={color} strokeWidth="1.6" strokeLinecap="round"/>
    </svg>
  ),
  Pipe: ({ size=22, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M4 7h6a4 4 0 0 1 4 4v6h6" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
      <path d="M3 5h3v4H3zM18 16h3v4h-3z" stroke={color} strokeWidth="1.6" strokeLinejoin="round"/>
      <circle cx="11" cy="14" r="1" fill={color}/>
      <circle cx="13" cy="9" r="1" fill={color}/>
    </svg>
  ),
  Plug: ({ size=22, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M9 2v5m6-5v5" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
      <path d="M5 7h14v4a7 7 0 0 1-7 7 7 7 0 0 1-7-7V7Z" stroke={color} strokeWidth="1.6" strokeLinejoin="round"/>
      <path d="M12 18v4" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
    </svg>
  ),
  Broom: ({ size=22, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="m14 3-7 7 4 4 7-7-4-4Z" stroke={color} strokeWidth="1.6" strokeLinejoin="round"/>
      <path d="M11 14 4 21l3-1 3 1 3-1 3 1-1-3 1-3-3-1Z" stroke={color} strokeWidth="1.6" strokeLinejoin="round"/>
    </svg>
  ),
  Leaf: ({ size=22, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M4 20c0-9 6-15 16-15 0 10-6 16-15 16-1 0-1-1-1-1Z" stroke={color} strokeWidth="1.6" strokeLinejoin="round"/>
      <path d="M4 20 16 8" stroke={color} strokeWidth="1.6" strokeLinecap="round"/>
    </svg>
  ),
  Wrench: ({ size=22, color='currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M14.5 3a5 5 0 0 0-3.7 8.36l-7.4 7.4a2 2 0 1 0 2.83 2.83l7.4-7.4A5 5 0 1 0 14.5 3Z" stroke={color} strokeWidth="1.6" strokeLinejoin="round"/>
    </svg>
  ),
  // Bottom nav
  NavHome: ({ size=22, color='currentColor', filled=false }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={filled?color:'none'}>
      <path d="M4 11 12 4l8 7v9a1 1 0 0 1-1 1h-4v-6h-6v6H5a1 1 0 0 1-1-1v-9Z" stroke={color} strokeWidth="1.6" strokeLinejoin="round"/>
    </svg>
  ),
  NavCamera: ({ size=22, color='currentColor', filled=false }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={filled?color:'none'}>
      <path d="M3 8a2 2 0 0 1 2-2h2.6l1.4-2h6l1.4 2H19a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8Z" stroke={color} strokeWidth="1.6"/>
      <circle cx="12" cy="13" r="3.6" stroke={color} strokeWidth="1.6" fill={filled?'#fff':'none'}/>
    </svg>
  ),
  NavWorkers: ({ size=22, color='currentColor', filled=false }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={filled?color:'none'}>
      <circle cx="9" cy="8" r="3.5" stroke={color} strokeWidth="1.6"/>
      <circle cx="17" cy="9.5" r="2.5" stroke={color} strokeWidth="1.6"/>
      <path d="M3 19c.5-3.3 3-5 6-5s5.5 1.7 6 5M15 14c2.4 0 4.4 1.4 5 4" stroke={color} strokeWidth="1.6" strokeLinecap="round"/>
    </svg>
  ),
  NavHistory: ({ size=22, color='currentColor', filled=false }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={filled?color:'none'}>
      <circle cx="12" cy="12" r="9" stroke={color} strokeWidth="1.6"/>
      <path d="M12 7v5l3.5 2" stroke={color} strokeWidth="1.6" strokeLinecap="round"/>
    </svg>
  ),
  NavProfile: ({ size=22, color='currentColor', filled=false }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={filled?color:'none'}>
      <circle cx="12" cy="8" r="4" stroke={color} strokeWidth="1.6"/>
      <path d="M4 21c.7-4.5 4-7 8-7s7.3 2.5 8 7" stroke={color} strokeWidth="1.6" strokeLinecap="round"/>
    </svg>
  ),
  Verified: ({ size=14, color='#0E8E6C' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24">
      <path d="m12 1 2.4 2-3 .4 2 2.4-2.7 1.4 1.5 2.7-3 .3 1 2.8-3-.4-.4 3-2.6-1.5-1.5 2.7L0 13l-.5-3 3 .4-1-2.8 3-.3-1.5-2.7L5.7 3 8.7 4 9.5 1 12 1Z" fill={color} transform="translate(0,2) scale(1.1) translate(.3,.3)"/>
      <path d="M12 2 14 4l3-.5L17 6.5l3 1L19 11l1.5 2.7L17.5 15 17 18l-3-.5L12 21l-2-3.5L7 18l-.5-3L3.5 15 5 11.7 4 8.5l3-1L7 4.5l3 .5L12 2Z" fill={color}/>
      <path d="m8.5 12 2.3 2.3 4.7-4.7" stroke="#fff" strokeWidth="1.8" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
};
window.Icon = Icon;
